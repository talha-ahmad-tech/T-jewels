import type { CartProduct } from '@/lib/cart';
import type { Product } from '@/lib/types';

export function makeProduct(overrides: Partial<Product> = {}): Product {
  return {
    id: 1,
    name: 'Aurora solitaire ring',
    slug: 'aurora-solitaire-ring',
    description: 'A single round stone held high in four claws.',
    material: '925 sterling silver, 18k gold vermeil',
    price: 8500,
    stockQuantity: 12,
    picture: '/jewels/aurora-solitaire-ring.svg',
    isFeatured: true,
    categoryName: 'Rings',
    categorySlug: 'rings',
    ...overrides,
  };
}

export function makeCartProduct(overrides: Partial<CartProduct> = {}): CartProduct {
  return {
    productId: 1,
    slug: 'aurora-solitaire-ring',
    name: 'Aurora solitaire ring',
    price: 8500,
    picture: '/jewels/aurora-solitaire-ring.svg',
    maxQuantity: 12,
    ...overrides,
  };
}
