import { render, screen } from '@testing-library/react';
import { ProductCard } from '@/app/components/product-card';
import { makeProduct } from '../fixtures';

describe('ProductCard', () => {
  it('shows the name, material and price, and links to the product page', () => {
    render(<ProductCard product={makeProduct()} />);

    expect(screen.getByRole('heading', { name: 'Aurora solitaire ring' })).toBeInTheDocument();
    expect(screen.getByText('925 sterling silver, 18k gold vermeil')).toBeInTheDocument();
    expect(screen.getByText('PKR 8,500')).toBeInTheDocument();
    expect(screen.getByRole('link')).toHaveAttribute('href', '/products/aurora-solitaire-ring');
    expect(screen.getByRole('img', { name: 'Aurora solitaire ring' })).toBeInTheDocument();
  });

  it('does not show a stock note when plenty are available', () => {
    render(<ProductCard product={makeProduct({ stockQuantity: 12 })} />);

    expect(screen.queryByText(/left/)).not.toBeInTheDocument();
    expect(screen.queryByText('Sold out')).not.toBeInTheDocument();
  });

  it('warns when only a few pieces are left', () => {
    render(<ProductCard product={makeProduct({ stockQuantity: 3 })} />);

    expect(screen.getByText('Only 3 left')).toBeInTheDocument();
  });

  it('marks sold-out pieces', () => {
    render(<ProductCard product={makeProduct({ stockQuantity: 0 })} />);

    expect(screen.getByText('Sold out')).toBeInTheDocument();
  });

  it('falls back to a monogram when there is no picture', () => {
    render(<ProductCard product={makeProduct({ picture: null })} />);

    expect(screen.queryByRole('img')).not.toBeInTheDocument();
    expect(screen.getByText('T')).toBeInTheDocument();
  });
});
