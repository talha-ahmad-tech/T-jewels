import { render, renderHook, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { AddToBag } from '@/app/components/add-to-bag';
import { clearCart, useCart } from '@/lib/cart-store';
import { makeCartProduct } from '../fixtures';

describe('AddToBag', () => {
  beforeEach(() => {
    clearCart();
    window.localStorage.clear();
  });

  it('adds the chosen quantity to the bag and confirms it', async () => {
    const user = userEvent.setup();
    render(<AddToBag product={makeCartProduct()} />);

    await user.click(screen.getByRole('button', { name: 'Increase quantity' }));
    await user.click(screen.getByRole('button', { name: 'Add to bag' }));

    const { result } = renderHook(() => useCart());
    expect(result.current.count).toBe(2);
    expect(result.current.subtotal).toBe(17000);
    expect(screen.getByText(/Added to your bag/)).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'View bag' })).toHaveAttribute('href', '/bag');
    expect(JSON.parse(window.localStorage.getItem('tjewels-bag') ?? '[]')).toHaveLength(1);
  });

  it('does not let the quantity go past the stock available', async () => {
    const user = userEvent.setup();
    render(<AddToBag product={makeCartProduct({ maxQuantity: 2 })} />);

    const increase = screen.getByRole('button', { name: 'Increase quantity' });
    await user.click(increase);

    expect(screen.getByRole('group', { name: 'Quantity' })).toHaveTextContent('2');
    expect(increase).toBeDisabled();
  });

  it('stops adding once every available piece is in the bag', async () => {
    const user = userEvent.setup();
    render(<AddToBag product={makeCartProduct({ maxQuantity: 1 })} />);

    await user.click(screen.getByRole('button', { name: 'Add to bag' }));

    expect(screen.getByRole('button', { name: 'Add to bag' })).toBeDisabled();
  });

  it('shows a disabled button for sold-out pieces', () => {
    render(<AddToBag product={makeCartProduct({ maxQuantity: 0 })} />);

    expect(screen.getByRole('button', { name: 'Sold out' })).toBeDisabled();
    expect(screen.queryByRole('button', { name: 'Add to bag' })).not.toBeInTheDocument();
  });
});
