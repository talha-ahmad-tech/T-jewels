import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ShopToolbar } from '@/app/components/shop-toolbar';

const mockPush = jest.fn();

jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: mockPush }),
}));

describe('ShopToolbar', () => {
  beforeEach(() => mockPush.mockReset());

  it('searches within the current collection', async () => {
    const user = userEvent.setup();
    render(<ShopToolbar category="rings" sort="newest" />);

    await user.type(screen.getByRole('searchbox', { name: 'Search jewellery' }), '  gold  {Enter}');

    expect(mockPush).toHaveBeenCalledWith('/products?category=rings&q=gold');
  });

  it('keeps the search when the sort order changes', async () => {
    const user = userEvent.setup();
    render(<ShopToolbar search="pearl" sort="newest" />);

    await user.selectOptions(screen.getByLabelText('Sort by'), 'Price: low to high');

    expect(mockPush).toHaveBeenCalledWith('/products?q=pearl&sort=price-asc');
  });

  it('shows the current search and sort', () => {
    render(<ShopToolbar search="kada" sort="price-desc" />);

    expect(screen.getByRole('searchbox', { name: 'Search jewellery' })).toHaveValue('kada');
    expect(screen.getByLabelText('Sort by')).toHaveValue('price-desc');
  });
});
