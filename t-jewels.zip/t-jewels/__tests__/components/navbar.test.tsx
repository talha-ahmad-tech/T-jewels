import { act, render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Navbar from '@/app/components/navbar';
import { addToCart, clearCart } from '@/lib/cart-store';
import { makeCartProduct } from '../fixtures';

const mockUsePathname = jest.fn(() => '/');

jest.mock('next/navigation', () => ({
  usePathname: () => mockUsePathname(),
}));

jest.mock('@/app/actions/auth', () => ({
  signOut: jest.fn(),
}));

describe('Navbar', () => {
  beforeEach(() => {
    clearCart();
    mockUsePathname.mockReturnValue('/');
  });

  it('shows the brand, main links and a sign-in link for guests', () => {
    render(<Navbar user={null} />);

    expect(screen.getByRole('link', { name: 'T Jewels home' })).toHaveAttribute('href', '/');
    const main = screen.getByRole('navigation', { name: 'Main' });
    expect(within(main).getByRole('link', { name: 'Shop' })).toHaveAttribute('href', '/products');
    expect(within(main).getByRole('link', { name: 'Collections' })).toHaveAttribute('href', '/collections');
    expect(screen.getByRole('link', { name: 'Sign in' })).toHaveAttribute('href', '/login');
  });

  it('greets a signed-in customer by first name and links to their account', () => {
    render(<Navbar user={{ name: 'Ayesha Khan' }} />);

    expect(screen.getByRole('link', { name: 'Ayesha' })).toHaveAttribute('href', '/account');
    expect(screen.queryByRole('link', { name: 'Sign in' })).not.toBeInTheDocument();
  });

  it('marks the current section', () => {
    mockUsePathname.mockReturnValue('/products/aurora-solitaire-ring');
    render(<Navbar user={null} />);

    const main = screen.getByRole('navigation', { name: 'Main' });
    expect(within(main).getByRole('link', { name: 'Shop' })).toHaveAttribute('aria-current', 'page');
    expect(within(main).getByRole('link', { name: 'Collections' })).not.toHaveAttribute('aria-current');
  });

  it('shows how many pieces are in the bag', () => {
    render(<Navbar user={null} />);
    expect(screen.getByRole('link', { name: 'Bag' })).toBeInTheDocument();

    act(() => addToCart(makeCartProduct(), 2));

    expect(screen.getByRole('link', { name: 'Bag, 2 items' })).toHaveAttribute('href', '/bag');
    expect(screen.getByText('2')).toBeInTheDocument();
  });

  it('opens and closes the mobile menu', async () => {
    const user = userEvent.setup();
    render(<Navbar user={{ name: 'Ayesha Khan' }} />);

    const toggle = screen.getByRole('button', { name: 'Open menu' });
    expect(toggle).toHaveAttribute('aria-expanded', 'false');

    await user.click(toggle);
    const menu = screen.getByRole('navigation', { name: 'Mobile' });
    expect(within(menu).getByRole('link', { name: 'Your account' })).toBeInTheDocument();
    expect(within(menu).getByRole('button', { name: 'Sign out' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Close menu' })).toHaveAttribute('aria-expanded', 'true');

    const stayOnPage = (event: MouseEvent) => event.preventDefault();
    document.addEventListener('click', stayOnPage);
    await user.click(within(menu).getByRole('link', { name: 'Collections' }));
    document.removeEventListener('click', stayOnPage);

    expect(screen.queryByRole('navigation', { name: 'Mobile' })).not.toBeInTheDocument();
  });
});
