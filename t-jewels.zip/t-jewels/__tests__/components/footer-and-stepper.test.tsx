import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Footer from '@/app/components/footer';
import { QuantityStepper } from '@/app/components/quantity-stepper';
import { StockNote } from '@/app/components/stock-note';

describe('Footer', () => {
  it('links to the shop and account pages', () => {
    render(<Footer />);

    const shop = screen.getByRole('navigation', { name: 'Shop' });
    expect(within(shop).getByRole('link', { name: 'Bridal sets' })).toHaveAttribute('href', '/products?category=bridal');
    const account = screen.getByRole('navigation', { name: 'Your account' });
    expect(within(account).getByRole('link', { name: 'Your bag' })).toHaveAttribute('href', '/bag');
    expect(screen.getByText('© 2026 T Jewels')).toBeInTheDocument();
  });
});

describe('QuantityStepper', () => {
  it('steps up and down within its limits', async () => {
    const user = userEvent.setup();
    const onChange = jest.fn();
    render(<QuantityStepper value={1} max={3} label="Quantity" onChange={onChange} />);

    expect(screen.getByRole('button', { name: 'Decrease quantity' })).toBeDisabled();
    await user.click(screen.getByRole('button', { name: 'Increase quantity' }));

    expect(onChange).toHaveBeenCalledWith(2);
  });

  it('disables the increase button at the maximum', () => {
    render(<QuantityStepper value={3} max={3} label="Quantity" onChange={jest.fn()} />);

    expect(screen.getByRole('button', { name: 'Increase quantity' })).toBeDisabled();
    expect(screen.getByRole('button', { name: 'Decrease quantity' })).toBeEnabled();
  });
});

describe('StockNote', () => {
  it.each([
    [0, 'Sold out'],
    [4, 'Only 4 left'],
    [20, 'In stock'],
  ])('shows the right note for %i in stock', (stock, text) => {
    render(<StockNote stock={stock} />);
    expect(screen.getByText(text)).toBeInTheDocument();
  });
});
