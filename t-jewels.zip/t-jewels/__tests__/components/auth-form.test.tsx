import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { AuthForm } from '@/app/components/auth-form';
import { signIn, signUp } from '@/app/actions/auth';

jest.mock('@/app/actions/auth', () => ({
  signIn: jest.fn(),
  signUp: jest.fn(),
}));

const mockSignIn = signIn as jest.MockedFunction<typeof signIn>;
const mockSignUp = signUp as jest.MockedFunction<typeof signUp>;

describe('AuthForm', () => {
  beforeEach(() => {
    mockSignIn.mockReset();
    mockSignUp.mockReset();
  });

  it('renders the sign-in form and keeps the return path on the sign-up link', () => {
    render(<AuthForm mode="signin" next="/bag" />);

    expect(screen.getByLabelText('Email')).toHaveAttribute('type', 'email');
    expect(screen.getByLabelText('Password')).toHaveAttribute('autocomplete', 'current-password');
    expect(screen.queryByLabelText('Full name')).not.toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Create an account' })).toHaveAttribute('href', '/register?next=%2Fbag');
  });

  it('renders the sign-up form with a password hint', () => {
    render(<AuthForm mode="signup" />);

    expect(screen.getByLabelText('Full name')).toBeRequired();
    expect(screen.getByLabelText('Password')).toHaveAccessibleDescription('At least 8 characters.');
    expect(screen.getByRole('link', { name: 'Sign in' })).toHaveAttribute('href', '/login');
  });

  it('shows the error returned by the server and keeps the email', async () => {
    const user = userEvent.setup();
    mockSignIn.mockResolvedValue({
      error: 'That email and password don’t match an account.',
      fields: { email: 'ayesha@example.com' },
    });
    render(<AuthForm mode="signin" next="/bag" />);

    await user.type(screen.getByLabelText('Email'), 'ayesha@example.com');
    await user.type(screen.getByLabelText('Password'), 'wrong-password');
    await user.click(screen.getByRole('button', { name: 'Sign in' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('don’t match an account');
    expect(screen.getByLabelText('Email')).toHaveValue('ayesha@example.com');
    const formData = mockSignIn.mock.calls[0][1];
    expect(formData.get('next')).toBe('/bag');
    expect(formData.get('password')).toBe('wrong-password');
  });
});
