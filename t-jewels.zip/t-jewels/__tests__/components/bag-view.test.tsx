import { act, render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { BagView } from '@/app/components/bag-view';
import { placeOrder } from '@/app/actions/orders';
import { addToCart, clearCart } from '@/lib/cart-store';
import { makeCartProduct } from '../fixtures';

const mockPush = jest.fn();

jest.mock('next/navigation', () => ({
  useRouter: () => ({ push: mockPush }),
}));

jest.mock('@/app/actions/orders', () => ({
  placeOrder: jest.fn(),
}));

const mockPlaceOrder = placeOrder as jest.MockedFunction<typeof placeOrder>;

const studs = makeCartProduct({
  productId: 2,
  slug: 'moti-pearl-studs',
  name: 'Moti pearl studs',
  price: 3900,
  picture: '/jewels/moti-pearl-studs.svg',
  maxQuantity: 25,
});

describe('BagView', () => {
  beforeEach(() => {
    clearCart();
    mockPush.mockReset();
    mockPlaceOrder.mockReset();
  });

  it('invites the customer to shop when the bag is empty', () => {
    render(<BagView user={null} />);

    expect(screen.getByRole('heading', { name: 'Your bag is empty' })).toBeInTheDocument();
    expect(screen.getByRole('link', { name: 'Shop all jewellery' })).toHaveAttribute('href', '/products');
  });

  it('lists pieces with totals and charges delivery on small orders', () => {
    act(() => addToCart(studs, 1));
    render(<BagView user={null} />);

    expect(screen.getByRole('link', { name: 'Moti pearl studs' })).toHaveAttribute('href', '/products/moti-pearl-studs');
    const summary = screen.getByRole('complementary', { name: 'Order summary' });
    expect(within(summary).getByText('Subtotal (1 piece)')).toBeInTheDocument();
    expect(within(summary).getByText('PKR 250')).toBeInTheDocument();
    expect(within(summary).getByText('PKR 4,150')).toBeInTheDocument();
    expect(screen.getByText('Add PKR 6,100 more for free delivery.')).toBeInTheDocument();
  });

  it('updates quantities and removes pieces', async () => {
    const user = userEvent.setup();
    act(() => {
      addToCart(makeCartProduct(), 1);
      addToCart(studs, 1);
    });
    render(<BagView user={null} />);

    const ringQuantity = screen.getByRole('group', { name: 'Quantity of Aurora solitaire ring' });
    await user.click(within(ringQuantity).getByRole('button', { name: 'Increase quantity' }));

    const summary = screen.getByRole('complementary', { name: 'Order summary' });
    expect(within(summary).getByText('Subtotal (3 pieces)')).toBeInTheDocument();
    expect(within(summary).getByText('Free')).toBeInTheDocument();

    await user.click(screen.getByRole('button', { name: 'Remove Moti pearl studs' }));
    expect(screen.queryByRole('link', { name: 'Moti pearl studs' })).not.toBeInTheDocument();
    expect(within(summary).getByText('Subtotal (2 pieces)')).toBeInTheDocument();
  });

  it('asks guests to sign in before checking out', () => {
    act(() => addToCart(studs, 1));
    render(<BagView user={null} />);

    expect(screen.getByRole('link', { name: 'Sign in to check out' })).toHaveAttribute('href', '/login?next=/bag');
    expect(screen.queryByRole('button', { name: 'Place order' })).not.toBeInTheDocument();
  });

  it('places the order, empties the bag and opens the account page', async () => {
    const user = userEvent.setup();
    mockPlaceOrder.mockResolvedValue({ orderId: 7 });
    act(() => addToCart(makeCartProduct(), 2));
    render(<BagView user={{ name: 'Ayesha Khan' }} />);

    expect(screen.getByLabelText('Full name')).toHaveValue('Ayesha Khan');
    await user.type(screen.getByLabelText('Phone'), '0300 1234567');
    await user.type(screen.getByLabelText('Address'), 'House 12, Street 4, DHA Phase 5');
    await user.type(screen.getByLabelText('City'), 'Lahore');
    await user.click(screen.getByRole('button', { name: 'Place order' }));

    await waitFor(() => expect(mockPush).toHaveBeenCalledWith('/account?order=7'));
    const formData = mockPlaceOrder.mock.calls[0][1];
    expect(JSON.parse(String(formData.get('items')))).toEqual([{ productId: 1, quantity: 2 }]);
    expect(formData.get('city')).toBe('Lahore');
    expect(screen.getByRole('heading', { name: 'Your bag is empty' })).toBeInTheDocument();
  });

  it('shows the reason when an order cannot be placed', async () => {
    const user = userEvent.setup();
    mockPlaceOrder.mockResolvedValue({
      error: 'Enter a phone number we can call, like 0300 1234567.',
      fields: { name: 'Ayesha Khan', phone: '12', address: 'House 12, Street 4, DHA Phase 5', city: 'Lahore' },
    });
    act(() => addToCart(studs, 1));
    render(<BagView user={{ name: 'Ayesha Khan' }} />);

    await user.type(screen.getByLabelText('Phone'), '12');
    await user.type(screen.getByLabelText('Address'), 'House 12, Street 4, DHA Phase 5');
    await user.type(screen.getByLabelText('City'), 'Lahore');
    await user.click(screen.getByRole('button', { name: 'Place order' }));

    expect(await screen.findByRole('alert')).toHaveTextContent('Enter a phone number we can call');
    expect(screen.getByLabelText('Address')).toHaveValue('House 12, Street 4, DHA Phase 5');
    expect(mockPush).not.toHaveBeenCalled();
  });
});
