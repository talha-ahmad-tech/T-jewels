import { hashPassword, verifyPassword } from '@/lib/password';

describe('password hashing', () => {
  it('stores a salted scrypt hash, never the password', async () => {
    const first = await hashPassword('pearls-and-gold');
    const second = await hashPassword('pearls-and-gold');

    expect(first).toMatch(/^scrypt:[0-9a-f]{32}:[0-9a-f]{128}$/);
    expect(first).not.toContain('pearls-and-gold');
    expect(first).not.toBe(second);
  });

  it('accepts the right password and rejects others', async () => {
    const hash = await hashPassword('pearls-and-gold');

    await expect(verifyPassword('pearls-and-gold', hash)).resolves.toBe(true);
    await expect(verifyPassword('pearls-and-silver', hash)).resolves.toBe(false);
  });

  it('rejects hashes in an unknown format', async () => {
    await expect(verifyPassword('anything', 'plain-text')).resolves.toBe(false);
  });
});
