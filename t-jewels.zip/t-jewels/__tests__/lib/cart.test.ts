import {
  addItem,
  cartCount,
  cartSubtotal,
  deliveryFeeFor,
  isCartItem,
  MAX_PER_ITEM,
  removeItem,
  setItemQuantity,
} from '@/lib/cart';
import { makeCartProduct } from '../fixtures';

describe('cart helpers', () => {
  it('adds new pieces and merges repeats', () => {
    const once = addItem([], makeCartProduct(), 1);
    const twice = addItem(once, makeCartProduct(), 2);

    expect(twice).toHaveLength(1);
    expect(twice[0].quantity).toBe(3);
  });

  it('never goes past the stock or the per-piece limit', () => {
    expect(addItem([], makeCartProduct({ maxQuantity: 2 }), 5)[0].quantity).toBe(2);
    expect(addItem([], makeCartProduct({ maxQuantity: 50 }), 50)[0].quantity).toBe(MAX_PER_ITEM);
    expect(addItem([], makeCartProduct({ maxQuantity: 0 }), 1)).toEqual([]);
  });

  it('updates and removes quantities', () => {
    const items = addItem([], makeCartProduct(), 2);

    expect(setItemQuantity(items, 1, 4)[0].quantity).toBe(4);
    expect(setItemQuantity(items, 1, 0)).toEqual([]);
    expect(removeItem(items, 1)).toEqual([]);
  });

  it('counts pieces and adds up the subtotal', () => {
    const items = addItem(addItem([], makeCartProduct(), 2), makeCartProduct({ productId: 2, price: 3900 }), 1);

    expect(cartCount(items)).toBe(3);
    expect(cartSubtotal(items)).toBe(20900);
  });

  it('charges delivery only on small orders', () => {
    expect(deliveryFeeFor(0)).toBe(0);
    expect(deliveryFeeFor(3900)).toBe(250);
    expect(deliveryFeeFor(10000)).toBe(0);
  });

  it('rejects malformed saved bag items', () => {
    expect(isCartItem({ ...makeCartProduct(), quantity: 1 })).toBe(true);
    expect(isCartItem({ productId: '1', name: 'Ring' })).toBe(false);
    expect(isCartItem(null)).toBe(false);
  });
});
