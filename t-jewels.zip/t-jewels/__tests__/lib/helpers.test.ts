import { formatDate, formatPrice, pluralize } from '@/lib/format';
import { safeNextPath } from '@/lib/next-path';
import { shopUrl } from '@/lib/shop-url';

describe('formatting', () => {
  it('formats prices in rupees', () => {
    expect(formatPrice(45000)).toBe('PKR 45,000');
    expect(formatPrice(250)).toBe('PKR 250');
  });

  it('formats dates in Pakistan time', () => {
    expect(formatDate('2026-10-27T20:30:00Z')).toBe('28 Oct 2026');
  });

  it('pluralizes counts', () => {
    expect(pluralize(1, 'piece')).toBe('1 piece');
    expect(pluralize(4, 'piece')).toBe('4 pieces');
  });
});

describe('shopUrl', () => {
  it('builds shop links from filters', () => {
    expect(shopUrl()).toBe('/products');
    expect(shopUrl({ category: 'rings', search: 'gold', sort: 'price-asc' })).toBe('/products?category=rings&q=gold&sort=price-asc');
    expect(shopUrl({ sort: 'newest' })).toBe('/products');
  });
});

describe('safeNextPath', () => {
  it('only allows paths on this site', () => {
    expect(safeNextPath('/bag')).toBe('/bag');
    expect(safeNextPath('//evil.example')).toBeUndefined();
    expect(safeNextPath('/\\evil.example')).toBeUndefined();
    expect(safeNextPath('https://evil.example')).toBeUndefined();
    expect(safeNextPath(['/bag'])).toBeUndefined();
  });
});
