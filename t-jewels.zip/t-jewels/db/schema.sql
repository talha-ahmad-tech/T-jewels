create table if not exists categories (
  id integer generated always as identity primary key,
  name text not null,
  slug text not null unique,
  description text,
  picture text,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists products (
  id integer generated always as identity primary key,
  category_id integer references categories (id) on delete set null,
  name text not null,
  slug text not null unique,
  description text,
  material text,
  price integer not null check (price >= 0),
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  picture text,
  is_featured boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists products_category_id_idx on products (category_id);

create table if not exists users (
  id integer generated always as identity primary key,
  name text not null,
  email text not null unique check (email = lower(email)),
  password_hash text not null,
  created_at timestamptz not null default now()
);

create table if not exists sessions (
  id text primary key,
  user_id integer not null references users (id) on delete cascade,
  expires_at timestamptz not null,
  created_at timestamptz not null default now()
);

create index if not exists sessions_user_id_idx on sessions (user_id);

create table if not exists orders (
  id integer generated always as identity primary key,
  user_id integer not null references users (id) on delete cascade,
  status text not null default 'placed'
    check (status in ('placed', 'confirmed', 'shipped', 'delivered', 'cancelled')),
  customer_name text not null,
  phone text not null,
  address text not null,
  city text not null,
  subtotal integer not null check (subtotal >= 0),
  delivery_fee integer not null default 0 check (delivery_fee >= 0),
  total integer not null check (total >= 0),
  created_at timestamptz not null default now()
);

create index if not exists orders_user_id_idx on orders (user_id);

create table if not exists order_items (
  id integer generated always as identity primary key,
  order_id integer not null references orders (id) on delete cascade,
  product_id integer references products (id) on delete set null,
  product_name text not null,
  unit_price integer not null check (unit_price >= 0),
  quantity integer not null check (quantity > 0)
);

create index if not exists order_items_order_id_idx on order_items (order_id);
create index if not exists order_items_product_id_idx on order_items (product_id);
