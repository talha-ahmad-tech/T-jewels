grant usage on schema public to tjewels_app;
grant select on categories, products to tjewels_app;
grant update (stock_quantity) on products to tjewels_app;
grant select, insert on users to tjewels_app;
grant select, insert, delete on sessions to tjewels_app;
grant select, insert on orders, order_items to tjewels_app;

revoke all on categories, products, users, sessions, orders, order_items from anon, authenticated;

alter table categories enable row level security;
alter table products enable row level security;
alter table users enable row level security;
alter table sessions enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;

create policy "App reads categories" on categories for select to tjewels_app using (true);
create policy "App reads products" on products for select to tjewels_app using (true);
create policy "App updates stock" on products for update to tjewels_app using (true) with check (stock_quantity >= 0);
create policy "App manages users" on users for all to tjewels_app using (true) with check (true);
create policy "App manages sessions" on sessions for all to tjewels_app using (true) with check (true);
create policy "App manages orders" on orders for all to tjewels_app using (true) with check (true);
create policy "App manages order items" on order_items for all to tjewels_app using (true) with check (true);
