# T Jewels

A small jewellery shop built with Next.js and PostgreSQL. Shoppers browse collections, search and sort pieces, add them to a bag, create an account and place cash-on-delivery orders.

Live: https://t-jewels.vercel.app

## Features

- Home page with featured pieces, collections, new arrivals and a bridal section
- Shop page with collection filters, search and sorting
- Product pages with stock status and related pieces
- Bag saved in the browser, with a delivery fee and free delivery over PKR 10,000
- Email and password accounts (scrypt password hashes, database sessions in an httpOnly cookie)
- Checkout that saves the order and reduces stock in one transaction
- Order history on the account page
- Jest and React Testing Library tests for components and helpers

## Tech

- Next.js 16 (App Router, Server Actions), React 19, TypeScript
- Tailwind CSS 4
- PostgreSQL with `pg` and plain SQL, hosted on Supabase
- Jest 30 and React Testing Library
- Vercel (Hobby plan)

## Getting started

1. Install dependencies:

   ```bash
   npm install
   ```

2. Copy `.env.example` to `.env.local` and set `DATABASE_URL` to your PostgreSQL connection string.

3. Create the tables and sample data:

   ```bash
   npm run db:setup
   ```

   Run this with a user that can create tables, such as a local `postgres` user. Skip it if you point at a database that is already set up.

4. Start the dev server and open http://localhost:3000:

   ```bash
   npm run dev
   ```

## Scripts

| Command | What it does |
| --- | --- |
| `npm run dev` | Start the dev server |
| `npm run build` | Build for production |
| `npm start` | Run the production build |
| `npm test` | Run the Jest tests |
| `npm run test:watch` | Run Jest in watch mode |
| `npm run lint` | Run ESLint |
| `npm run db:setup` | Apply `db/schema.sql` and `db/seed.sql` |

## Database

- `db/schema.sql`: tables for categories, products, users, sessions, orders and order items
- `db/seed.sql`: 5 collections and 17 pieces, safe to run more than once
- `db/supabase.sql`: grants, row level security and policies for the `tjewels_app` role

### Supabase setup

1. In the SQL editor, create a login role for the app:

   ```sql
   create role tjewels_app with login password 'use-a-long-random-password';
   ```

2. Run `db/schema.sql`, `db/seed.sql` and then `db/supabase.sql` in the SQL editor.

3. Connect through the transaction pooler on port 6543. The user name is the role followed by the project ref:

   ```
   postgresql://tjewels_app.<project-ref>:<password>@<pooler-host>:6543/postgres
   ```

   Copy the pooler host from Connect, then Transaction pooler, in the Supabase dashboard.

## Deploying to Vercel

1. Import the repository in Vercel. The framework is detected as Next.js.
2. Add `DATABASE_URL` with the pooler connection string for Production and Preview.
3. Set the function region close to the database. The live site runs in Mumbai (`bom1`), next to the Supabase project in `ap-south-1`.

## Project structure

```
app/            routes, layouts and pages
app/actions/    server actions for sign-in and orders
app/components/ UI components
lib/            database pool, queries, sessions, cart logic and helpers
db/             SQL schema, seed data and Supabase policies
scripts/        database setup script
__tests__/      Jest tests
public/jewels/  product illustrations
```
