import 'server-only';
import { cache } from 'react';
import { query } from './db';
import type { Category, Order, Product, SortOption } from './types';

const productColumns = `
  p.id, p.name, p.slug, p.description, p.material, p.price,
  p.stock_quantity as "stockQuantity", p.picture, p.is_featured as "isFeatured",
  c.name as "categoryName", c.slug as "categorySlug"`;

const categoryColumns = `
  c.id, c.name, c.slug, c.description, c.picture, count(p.id)::int as "productCount"`;

const sortOrder: Record<SortOption, string> = {
  newest: 'p.created_at desc',
  'price-asc': 'p.price asc, p.created_at desc',
  'price-desc': 'p.price desc, p.created_at desc',
};

export function getCategories() {
  return query<Category>(`
    select ${categoryColumns}
    from categories c
    left join products p on p.category_id = c.id
    group by c.id
    order by c.sort_order, c.name`);
}

export async function getCategory(slug: string) {
  const rows = await query<Category>(
    `select ${categoryColumns}
     from categories c
     left join products p on p.category_id = c.id
     where c.slug = $1
     group by c.id`,
    [slug],
  );
  return rows[0] ?? null;
}

export function getFeaturedProducts(limit = 3) {
  return query<Product>(
    `select ${productColumns}
     from products p
     left join categories c on c.id = p.category_id
     where p.is_featured
     order by c.sort_order, p.created_at desc
     limit $1`,
    [limit],
  );
}

export function getNewArrivals(limit = 4) {
  return query<Product>(
    `select ${productColumns}
     from products p
     left join categories c on c.id = p.category_id
     where p.stock_quantity > 0
     order by p.created_at desc
     limit $1`,
    [limit],
  );
}

export function getProducts({ category, search, sort = 'newest' }: { category?: string; search?: string; sort?: SortOption } = {}) {
  const conditions: string[] = [];
  const params: unknown[] = [];

  if (category) {
    params.push(category);
    conditions.push(`c.slug = $${params.length}`);
  }

  if (search) {
    params.push(`%${search.replace(/[\\%_]/g, '\\$&')}%`);
    conditions.push(`(p.name ilike $${params.length} or p.material ilike $${params.length} or c.name ilike $${params.length})`);
  }

  const where = conditions.length ? `where ${conditions.join(' and ')}` : '';

  return query<Product>(
    `select ${productColumns}
     from products p
     left join categories c on c.id = p.category_id
     ${where}
     order by ${sortOrder[sort]}`,
    params,
  );
}

export const getProductBySlug = cache(async (slug: string) => {
  const rows = await query<Product>(
    `select ${productColumns}
     from products p
     left join categories c on c.id = p.category_id
     where p.slug = $1`,
    [slug],
  );
  return rows[0] ?? null;
});

export function getRelatedProducts(product: Product, limit = 4) {
  return query<Product>(
    `select ${productColumns}
     from products p
     left join categories c on c.id = p.category_id
     where p.id <> $1
     order by (c.slug is not distinct from $2) desc, p.stock_quantity > 0 desc, p.created_at desc
     limit $3`,
    [product.id, product.categorySlug, limit],
  );
}

export function getOrdersForUser(userId: number) {
  return query<Order>(
    `select o.id, o.status, o.subtotal, o.delivery_fee as "deliveryFee", o.total, o.city,
            o.created_at as "createdAt",
            coalesce(
              json_agg(
                json_build_object(
                  'productName', oi.product_name,
                  'productSlug', p.slug,
                  'unitPrice', oi.unit_price,
                  'quantity', oi.quantity
                ) order by oi.id
              ) filter (where oi.id is not null),
              '[]'
            ) as items
     from orders o
     left join order_items oi on oi.order_id = o.id
     left join products p on p.id = oi.product_id
     where o.user_id = $1
     group by o.id
     order by o.created_at desc`,
    [userId],
  );
}
