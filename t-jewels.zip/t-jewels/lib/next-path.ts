export function safeNextPath(value: unknown) {
  return typeof value === 'string' && /^\/(?![/\\])/.test(value) ? value : undefined;
}
