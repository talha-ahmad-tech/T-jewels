export type CartItem = {
  productId: number;
  slug: string;
  name: string;
  price: number;
  picture: string | null;
  quantity: number;
  maxQuantity: number;
};

export type CartProduct = Omit<CartItem, 'quantity'>;

export const FREE_DELIVERY_THRESHOLD = 10000;
export const DELIVERY_FEE = 250;
export const MAX_PER_ITEM = 10;

function limitFor(item: Pick<CartItem, 'maxQuantity'>) {
  return Math.max(0, Math.min(item.maxQuantity, MAX_PER_ITEM));
}

export function addItem(items: CartItem[], product: CartProduct, quantity = 1): CartItem[] {
  const limit = limitFor(product);

  if (limit === 0 || quantity <= 0) {
    return items;
  }

  const existing = items.find((item) => item.productId === product.productId);

  if (existing) {
    return items.map((item) =>
      item.productId === product.productId
        ? { ...item, ...product, quantity: Math.min(item.quantity + quantity, limit) }
        : item,
    );
  }

  return [...items, { ...product, quantity: Math.min(quantity, limit) }];
}

export function removeItem(items: CartItem[], productId: number): CartItem[] {
  return items.filter((item) => item.productId !== productId);
}

export function setItemQuantity(items: CartItem[], productId: number, quantity: number): CartItem[] {
  if (quantity <= 0) {
    return removeItem(items, productId);
  }

  return items.map((item) =>
    item.productId === productId ? { ...item, quantity: Math.min(quantity, limitFor(item)) } : item,
  );
}

export function cartCount(items: CartItem[]) {
  return items.reduce((total, item) => total + item.quantity, 0);
}

export function cartSubtotal(items: CartItem[]) {
  return items.reduce((total, item) => total + item.price * item.quantity, 0);
}

export function deliveryFeeFor(subtotal: number) {
  return subtotal === 0 || subtotal >= FREE_DELIVERY_THRESHOLD ? 0 : DELIVERY_FEE;
}

export function isCartItem(value: unknown): value is CartItem {
  if (!value || typeof value !== 'object') {
    return false;
  }

  const item = value as Record<string, unknown>;

  return (
    Number.isInteger(item.productId) &&
    typeof item.slug === 'string' &&
    typeof item.name === 'string' &&
    typeof item.price === 'number' &&
    (item.picture === null || typeof item.picture === 'string') &&
    Number.isInteger(item.quantity) &&
    Number.isInteger(item.maxQuantity)
  );
}
