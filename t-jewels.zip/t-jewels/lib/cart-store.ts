import { useSyncExternalStore } from 'react';
import {
  addItem,
  cartCount,
  cartSubtotal,
  isCartItem,
  removeItem,
  setItemQuantity,
  type CartItem,
  type CartProduct,
} from './cart';

const STORAGE_KEY = 'tjewels-bag';
const EMPTY: CartItem[] = [];
const listeners = new Set<() => void>();

let items: CartItem[] = EMPTY;
let loaded = false;

function parse(raw: string | null): CartItem[] {
  if (!raw) {
    return EMPTY;
  }

  try {
    const data: unknown = JSON.parse(raw);
    return Array.isArray(data) ? data.filter(isCartItem) : EMPTY;
  } catch {
    return EMPTY;
  }
}

function readStorage() {
  try {
    return window.localStorage.getItem(STORAGE_KEY);
  } catch {
    return null;
  }
}

function writeStorage(next: CartItem[]) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    return true;
  } catch {
    return false;
  }
}

function getSnapshot() {
  if (!loaded) {
    items = parse(readStorage());
    loaded = true;
  }
  return items;
}

function getServerSnapshot() {
  return EMPTY;
}

function emit() {
  listeners.forEach((listener) => listener());
}

function subscribe(listener: () => void) {
  listeners.add(listener);

  const onStorage = (event: StorageEvent) => {
    if (event.key === STORAGE_KEY || event.key === null) {
      items = parse(event.newValue);
      emit();
    }
  };

  window.addEventListener('storage', onStorage);

  return () => {
    listeners.delete(listener);
    window.removeEventListener('storage', onStorage);
  };
}

function update(next: CartItem[]) {
  items = next;
  loaded = true;
  writeStorage(next);
  emit();
}

export function addToCart(product: CartProduct, quantity = 1) {
  update(addItem(getSnapshot(), product, quantity));
}

export function updateCartQuantity(productId: number, quantity: number) {
  update(setItemQuantity(getSnapshot(), productId, quantity));
}

export function removeFromCart(productId: number) {
  update(removeItem(getSnapshot(), productId));
}

export function clearCart() {
  update(EMPTY);
}

export function useCart() {
  const current = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  return {
    items: current,
    count: cartCount(current),
    subtotal: cartSubtotal(current),
  };
}
