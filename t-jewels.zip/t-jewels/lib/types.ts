export type Category = {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  picture: string | null;
  productCount: number;
};

export type Product = {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  material: string | null;
  price: number;
  stockQuantity: number;
  picture: string | null;
  isFeatured: boolean;
  categoryName: string | null;
  categorySlug: string | null;
};

export type User = {
  id: number;
  name: string;
  email: string;
};

export type OrderItem = {
  productName: string;
  productSlug: string | null;
  unitPrice: number;
  quantity: number;
};

export type Order = {
  id: number;
  status: string;
  subtotal: number;
  deliveryFee: number;
  total: number;
  city: string;
  createdAt: Date;
  items: OrderItem[];
};

export const SORT_OPTIONS = {
  newest: 'Newest',
  'price-asc': 'Price: low to high',
  'price-desc': 'Price: high to low',
} as const;

export type SortOption = keyof typeof SORT_OPTIONS;

export function isSortOption(value: unknown): value is SortOption {
  return typeof value === 'string' && value in SORT_OPTIONS;
}
