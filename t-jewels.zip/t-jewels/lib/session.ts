import 'server-only';
import { createHash, randomBytes } from 'node:crypto';
import { cache } from 'react';
import { cookies } from 'next/headers';
import { query } from './db';
import type { User } from './types';

const COOKIE_NAME = 'tj_session';
const SESSION_DAYS = 30;

function hashToken(token: string) {
  return createHash('sha256').update(token).digest('hex');
}

export async function createSession(userId: number) {
  const token = randomBytes(32).toString('base64url');
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);

  await query('delete from sessions where user_id = $1 and expires_at < now()', [userId]);
  await query('insert into sessions (id, user_id, expires_at) values ($1, $2, $3)', [hashToken(token), userId, expiresAt]);

  const cookieStore = await cookies();
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    expires: expiresAt,
  });
}

export const getCurrentUser = cache(async (): Promise<User | null> => {
  const token = (await cookies()).get(COOKIE_NAME)?.value;

  if (!token) {
    return null;
  }

  const rows = await query<User>(
    `select u.id, u.name, u.email
     from sessions s
     join users u on u.id = s.user_id
     where s.id = $1 and s.expires_at > now()`,
    [hashToken(token)],
  );

  return rows[0] ?? null;
});

export async function deleteSession() {
  const cookieStore = await cookies();
  const token = cookieStore.get(COOKIE_NAME)?.value;

  if (token) {
    await query('delete from sessions where id = $1', [hashToken(token)]);
  }

  cookieStore.delete(COOKIE_NAME);
}
