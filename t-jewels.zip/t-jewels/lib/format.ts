const priceFormat = new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 });

const dateFormat = new Intl.DateTimeFormat('en-GB', {
  day: 'numeric',
  month: 'short',
  year: 'numeric',
  timeZone: 'Asia/Karachi',
});

export function formatPrice(amount: number) {
  return `PKR ${priceFormat.format(amount)}`;
}

export function formatDate(value: Date | string) {
  return dateFormat.format(new Date(value));
}

export function pluralize(count: number, singular: string, plural = `${singular}s`) {
  return `${count} ${count === 1 ? singular : plural}`;
}
