import 'server-only';
import { connection } from 'next/server';
import { Pool, type QueryResultRow } from 'pg';
import { attachDatabasePool } from '@vercel/functions';

const globalForDb = globalThis as typeof globalThis & { tjewelsPool?: Pool };

function createPool() {
  const connectionString = process.env.DATABASE_URL;

  if (!connectionString) {
    throw new Error('DATABASE_URL is not set. Copy .env.example to .env.local and add your PostgreSQL connection string.');
  }

  const { hostname } = new URL(connectionString);
  const isLocal = hostname === 'localhost' || hostname === '127.0.0.1';

  const pool = new Pool({
    connectionString,
    ssl: isLocal ? false : { rejectUnauthorized: false },
    max: 5,
    idleTimeoutMillis: 5000,
  });

  attachDatabasePool(pool);
  return pool;
}

export function getPool() {
  globalForDb.tjewelsPool ??= createPool();
  return globalForDb.tjewelsPool;
}

export async function query<T extends QueryResultRow>(text: string, params: unknown[] = []) {
  await connection();
  const result = await getPool().query<T>(text, params);
  return result.rows;
}
