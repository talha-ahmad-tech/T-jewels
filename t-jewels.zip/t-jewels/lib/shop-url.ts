import type { SortOption } from './types';

type ShopFilters = {
  category?: string;
  search?: string;
  sort?: SortOption;
};

export function shopUrl({ category, search, sort }: ShopFilters = {}) {
  const params = new URLSearchParams();

  if (category) {
    params.set('category', category);
  }

  if (search) {
    params.set('q', search);
  }

  if (sort && sort !== 'newest') {
    params.set('sort', sort);
  }

  const queryString = params.toString();
  return queryString ? `/products?${queryString}` : '/products';
}
