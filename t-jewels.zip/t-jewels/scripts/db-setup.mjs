import { readFile } from 'node:fs/promises';
import pg from 'pg';

const connectionString = process.env.DATABASE_URL;

if (!connectionString) {
  console.error('DATABASE_URL is not set. Add it to .env.local first.');
  process.exit(1);
}

const { hostname } = new URL(connectionString);
const isLocal = hostname === 'localhost' || hostname === '127.0.0.1';
const client = new pg.Client({ connectionString, ssl: isLocal ? false : { rejectUnauthorized: false } });

await client.connect();

try {
  for (const file of ['db/schema.sql', 'db/seed.sql']) {
    const sql = await readFile(new URL(`../${file}`, import.meta.url), 'utf8');
    await client.query(sql);
    console.log(`Applied ${file}`);
  }
} finally {
  await client.end();
}
