'use server';

import { redirect } from 'next/navigation';
import { query } from '@/lib/db';
import { safeNextPath } from '@/lib/next-path';
import { hashPassword, verifyPassword } from '@/lib/password';
import { createSession, deleteSession } from '@/lib/session';

export type AuthState = {
  error?: string;
  fields?: { name?: string; email?: string };
} | undefined;

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function readText(formData: FormData, key: string) {
  const value = formData.get(key);
  return typeof value === 'string' ? value.trim() : '';
}

function nextPath(formData: FormData) {
  return safeNextPath(readText(formData, 'next')) ?? '/account';
}

export async function signUp(_state: AuthState, formData: FormData): Promise<AuthState> {
  const name = readText(formData, 'name');
  const email = readText(formData, 'email').toLowerCase();
  const password = String(formData.get('password') ?? '');
  const fields = { name, email };

  if (name.length < 2) {
    return { error: 'Enter your full name.', fields };
  }

  if (!EMAIL_PATTERN.test(email)) {
    return { error: 'Enter an email address like name@example.com.', fields };
  }

  if (password.length < 8) {
    return { error: 'Use a password with at least 8 characters.', fields };
  }

  const passwordHash = await hashPassword(password);
  const [user] = await query<{ id: number }>(
    `insert into users (name, email, password_hash)
     values ($1, $2, $3)
     on conflict (email) do nothing
     returning id`,
    [name, email, passwordHash],
  );

  if (!user) {
    return { error: 'An account with this email already exists. Sign in instead.', fields };
  }

  await createSession(user.id);
  redirect(nextPath(formData));
}

export async function signIn(_state: AuthState, formData: FormData): Promise<AuthState> {
  const email = readText(formData, 'email').toLowerCase();
  const password = String(formData.get('password') ?? '');
  const fields = { email };

  if (!email || !password) {
    return { error: 'Enter your email and password.', fields };
  }

  const [user] = await query<{ id: number; password_hash: string }>(
    'select id, password_hash from users where email = $1',
    [email],
  );

  if (!user || !(await verifyPassword(password, user.password_hash))) {
    return { error: 'That email and password don’t match an account.', fields };
  }

  await createSession(user.id);
  redirect(nextPath(formData));
}

export async function signOut() {
  await deleteSession();
  redirect('/');
}
