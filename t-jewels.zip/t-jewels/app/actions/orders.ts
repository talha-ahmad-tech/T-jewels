'use server';

import { getPool } from '@/lib/db';
import { getCurrentUser } from '@/lib/session';
import { deliveryFeeFor, MAX_PER_ITEM } from '@/lib/cart';

type CheckoutFields = {
  name: string;
  phone: string;
  address: string;
  city: string;
};

export type CheckoutState = {
  error?: string;
  orderId?: number;
  fields?: CheckoutFields;
} | undefined;

type ProductRow = { id: number; name: string; price: number; stock: number };

function readText(formData: FormData, key: string) {
  const value = formData.get(key);
  return typeof value === 'string' ? value.trim() : '';
}

function readLines(formData: FormData) {
  const lines = new Map<number, number>();

  try {
    const data: unknown = JSON.parse(readText(formData, 'items') || '[]');

    if (Array.isArray(data)) {
      for (const line of data) {
        const productId = Number(line?.productId);
        const quantity = Number(line?.quantity);

        if (Number.isInteger(productId) && Number.isInteger(quantity) && quantity > 0) {
          lines.set(productId, Math.min((lines.get(productId) ?? 0) + quantity, MAX_PER_ITEM));
        }
      }
    }
  } catch {
    return lines;
  }

  return lines;
}

export async function placeOrder(_state: CheckoutState, formData: FormData): Promise<CheckoutState> {
  const fields: CheckoutFields = {
    name: readText(formData, 'name'),
    phone: readText(formData, 'phone'),
    address: readText(formData, 'address'),
    city: readText(formData, 'city'),
  };
  const fail = (error: string): CheckoutState => ({ error, fields });
  const user = await getCurrentUser();

  if (!user) {
    return fail('Sign in to place your order.');
  }

  const lines = readLines(formData);
  const phoneDigits = fields.phone.replace(/\D/g, '');

  if (lines.size === 0) {
    return fail('Your bag is empty.');
  }

  if (fields.name.length < 2) {
    return fail('Enter the name we should deliver to.');
  }

  if (phoneDigits.length < 10 || phoneDigits.length > 13) {
    return fail('Enter a phone number we can call, like 0300 1234567.');
  }

  if (fields.address.length < 8) {
    return fail('Enter your full delivery address.');
  }

  if (fields.city.length < 2) {
    return fail('Enter your city.');
  }

  const client = await getPool().connect();

  try {
    await client.query('begin');

    const { rows: products } = await client.query<ProductRow>(
      'select id, name, price, stock_quantity as stock from products where id = any($1::int[]) for update',
      [[...lines.keys()]],
    );
    const byId = new Map(products.map((product) => [product.id, product]));

    let subtotal = 0;

    for (const [productId, quantity] of lines) {
      const product = byId.get(productId);

      if (!product) {
        await client.query('rollback');
        return fail('A piece in your bag is no longer available. Remove it and try again.');
      }

      if (product.stock < quantity) {
        await client.query('rollback');
        return fail(
          product.stock === 0
            ? `${product.name} just sold out. Remove it from your bag to continue.`
            : `Only ${product.stock} of ${product.name} left. Lower the quantity to continue.`,
        );
      }

      subtotal += product.price * quantity;
    }

    const deliveryFee = deliveryFeeFor(subtotal);
    const { rows: [order] } = await client.query<{ id: number }>(
      `insert into orders (user_id, customer_name, phone, address, city, subtotal, delivery_fee, total)
       values ($1, $2, $3, $4, $5, $6, $7, $8)
       returning id`,
      [user.id, fields.name, fields.phone, fields.address, fields.city, subtotal, deliveryFee, subtotal + deliveryFee],
    );

    for (const [productId, quantity] of lines) {
      const product = byId.get(productId) as ProductRow;

      await client.query(
        'insert into order_items (order_id, product_id, product_name, unit_price, quantity) values ($1, $2, $3, $4, $5)',
        [order.id, product.id, product.name, product.price, quantity],
      );
      await client.query('update products set stock_quantity = stock_quantity - $1 where id = $2', [quantity, product.id]);
    }

    await client.query('commit');
    return { orderId: order.id };
  } catch (error) {
    await client.query('rollback');
    throw error;
  } finally {
    client.release();
  }
}
