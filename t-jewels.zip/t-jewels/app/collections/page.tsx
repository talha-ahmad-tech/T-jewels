import type { Metadata } from 'next';
import Link from 'next/link';
import { pluralize } from '@/lib/format';
import { getCategories } from '@/lib/queries';
import { JewelImage } from '../components/jewel-image';
import { containerStyles } from '../components/styles';

export const metadata: Metadata = {
  title: 'Collections',
};

export default async function CollectionsPage() {
  const categories = await getCategories();

  return (
    <div className={`${containerStyles} pb-20 pt-10`}>
      <h1 className="text-4xl sm:text-5xl">Collections</h1>
      <p className="mt-3 max-w-xl text-muted">Browse by the kind of piece you have in mind.</p>

      <ul className="mt-10 grid gap-x-10 gap-y-12 md:grid-cols-2">
        {categories.map((category) => (
          <li key={category.id}>
            <Link href={`/products?category=${category.slug}`} className="group grid grid-cols-[minmax(0,2fr)_minmax(0,3fr)] items-center gap-5">
              <JewelImage src={category.picture} alt="" sizes="(min-width: 768px) 20vw, 40vw" className="aspect-[4/5] bg-pearl" />
              <div>
                <h2 className="text-2xl group-hover:underline sm:text-3xl">{category.name}</h2>
                {category.description && <p className="mt-2 text-sm leading-6 text-muted">{category.description}</p>}
                <p className="mt-3 text-sm font-medium text-gold-ink">{pluralize(category.productCount, 'piece')}</p>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
