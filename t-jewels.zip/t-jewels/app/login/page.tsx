import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { safeNextPath } from '@/lib/next-path';
import { getCurrentUser } from '@/lib/session';
import { AuthForm } from '../components/auth-form';
import { AuthLayout } from '../components/auth-layout';

export const metadata: Metadata = {
  title: 'Sign in',
};

type LoginPageProps = {
  searchParams: Promise<{ next?: string | string[] }>;
};

export default async function LoginPage({ searchParams }: LoginPageProps) {
  const next = safeNextPath((await searchParams).next);

  if (await getCurrentUser()) {
    redirect(next ?? '/account');
  }

  return (
    <AuthLayout title="Sign in" intro="Sign in to place orders and see your order history.">
      <AuthForm mode="signin" next={next} />
    </AuthLayout>
  );
}
