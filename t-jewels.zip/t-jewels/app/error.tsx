'use client';

import Link from 'next/link';
import { buttonStyles, containerStyles } from './components/styles';

type ErrorPageProps = {
  error: Error & { digest?: string };
  retry: () => void;
};

export default function ErrorPage({ retry }: ErrorPageProps) {
  return (
    <div className={`${containerStyles} flex flex-col items-center py-24 text-center`}>
      <h1 className="text-4xl">This page didn’t load</h1>
      <p className="mt-3 max-w-md text-muted">
        The shop couldn’t reach its database just now. Try again in a moment, or go back to the homepage.
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <button type="button" onClick={() => retry()} className={buttonStyles.primary}>
          Try again
        </button>
        <Link href="/" className={buttonStyles.secondary}>
          Go to the homepage
        </Link>
      </div>
    </div>
  );
}
