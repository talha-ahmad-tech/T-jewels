import type { Metadata } from 'next';
import { getCurrentUser } from '@/lib/session';
import { BagView } from '../components/bag-view';
import { containerStyles } from '../components/styles';

export const metadata: Metadata = {
  title: 'Your bag',
};

export default async function BagPage() {
  const user = await getCurrentUser();

  return (
    <div className={`${containerStyles} pb-20 pt-10`}>
      <h1 className="text-4xl sm:text-5xl">Your bag</h1>
      <div className="mt-8">
        <BagView user={user ? { name: user.name } : null} />
      </div>
    </div>
  );
}
