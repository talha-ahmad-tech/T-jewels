import Link from 'next/link';
import { Logo } from './logo';
import { containerStyles } from './styles';

const shopLinks = [
  { label: 'All jewellery', href: '/products' },
  { label: 'Collections', href: '/collections' },
  { label: 'Bridal sets', href: '/products?category=bridal' },
];

const accountLinks = [
  { label: 'Your account', href: '/account' },
  { label: 'Your bag', href: '/bag' },
  { label: 'Create an account', href: '/register' },
];

export default function Footer() {
  return (
    <footer className="velvet text-white">
      <div className={`${containerStyles} grid gap-10 py-14 md:grid-cols-[1.6fr_1fr_1fr]`}>
        <div>
          <Logo tone="light" />
          <p className="mt-5 max-w-xs text-sm leading-6 text-white/70">
            Rings, earrings, necklaces and bridal sets, delivered anywhere in Pakistan. Pay in cash when your order arrives.
          </p>
        </div>
        <nav aria-labelledby="footer-shop">
          <h2 id="footer-shop" className="font-sans text-sm font-medium text-gold-light">
            Shop
          </h2>
          <ul className="mt-4 space-y-2.5 text-sm">
            {shopLinks.map(({ label, href }) => (
              <li key={href}>
                <Link href={href} className="text-white/75 transition-colors hover:text-white">
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <nav aria-labelledby="footer-account">
          <h2 id="footer-account" className="font-sans text-sm font-medium text-gold-light">
            Your account
          </h2>
          <ul className="mt-4 space-y-2.5 text-sm">
            {accountLinks.map(({ label, href }) => (
              <li key={href}>
                <Link href={href} className="text-white/75 transition-colors hover:text-white">
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
      <div className="border-t border-white/10">
        <p className={`${containerStyles} py-5 text-xs text-white/55`}>© 2026 T Jewels</p>
      </div>
    </footer>
  );
}
