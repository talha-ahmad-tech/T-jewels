import type { ReactNode } from 'react';
import { JewelImage } from './jewel-image';
import { containerStyles } from './styles';

type AuthLayoutProps = {
  title: string;
  intro: string;
  children: ReactNode;
};

export function AuthLayout({ title, intro, children }: AuthLayoutProps) {
  return (
    <div className={`${containerStyles} grid gap-10 py-10 md:grid-cols-2 md:items-center md:gap-16 md:py-16`}>
      <div className="velvet hidden rounded-md px-10 pb-10 pt-12 md:block">
        <div className="arch mx-auto max-w-xs bg-gold/70 p-[1.5px]">
          <JewelImage
            src="/jewels/gulnar-jhumka-earrings.svg"
            alt=""
            sizes="320px"
            className="aspect-[4/5] bg-velvet-deep"
            eager
          />
        </div>
        <p className="mx-auto mt-8 max-w-xs text-center font-display text-2xl leading-snug text-gold-light">
          Save your details once and order in a few taps next time.
        </p>
      </div>
      <div className="mx-auto w-full max-w-md">
        <h1 className="text-4xl sm:text-5xl">{title}</h1>
        <p className="mt-3 text-muted">{intro}</p>
        <div className="mt-8">{children}</div>
      </div>
    </div>
  );
}
