'use client';

import { useRouter } from 'next/navigation';
import type { FormEvent } from 'react';
import { shopUrl } from '@/lib/shop-url';
import { SORT_OPTIONS, isSortOption, type SortOption } from '@/lib/types';
import { SearchIcon } from './icons';

type ShopToolbarProps = {
  category?: string;
  search?: string;
  sort: SortOption;
};

export function ShopToolbar({ category, search = '', sort }: ShopToolbarProps) {
  const router = useRouter();

  const handleSearch = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const value = new FormData(event.currentTarget).get('q');
    router.push(shopUrl({ category, search: typeof value === 'string' ? value.trim() : '', sort }));
  };

  const handleSort = (value: string) => {
    router.push(shopUrl({ category, search, sort: isSortOption(value) ? value : 'newest' }));
  };

  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
      <form role="search" onSubmit={handleSearch} className="relative sm:w-72" key={search}>
        <label htmlFor="shop-search" className="sr-only">
          Search jewellery
        </label>
        <SearchIcon className="pointer-events-none absolute left-3.5 top-1/2 h-[1.1rem] w-[1.1rem] -translate-y-1/2 text-muted" />
        <input
          id="shop-search"
          name="q"
          type="search"
          defaultValue={search}
          placeholder="Search rings, pearls, gold…"
          className="w-full rounded-full border border-line bg-white py-2.5 pl-10 pr-4 text-base text-ink placeholder:text-muted/70 focus:border-gold-ink focus:outline-none sm:text-sm"
        />
      </form>
      <div className="flex items-center gap-2">
        <label htmlFor="shop-sort" className="shrink-0 text-sm text-muted">
          Sort by
        </label>
        <select
          id="shop-sort"
          value={sort}
          onChange={(event) => handleSort(event.target.value)}
          className="w-full rounded-full border border-line bg-white px-4 py-2.5 text-base text-ink focus:border-gold-ink focus:outline-none sm:w-auto sm:text-sm"
        >
          {Object.entries(SORT_OPTIONS).map(([value, label]) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </select>
      </div>
    </div>
  );
}
