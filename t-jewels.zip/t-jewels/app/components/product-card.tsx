import Link from 'next/link';
import type { Product } from '@/lib/types';
import { formatPrice } from '@/lib/format';
import { JewelImage } from './jewel-image';
import { StockNote } from './stock-note';

export function ProductCard({ product }: { product: Product }) {
  const soldOut = product.stockQuantity <= 0;

  return (
    <Link href={`/products/${product.slug}`} className="group block">
      <JewelImage
        src={product.picture}
        alt={product.name}
        sizes="(min-width: 1024px) 22vw, (min-width: 640px) 30vw, 45vw"
        className={`aspect-[4/5] bg-pearl transition-colors duration-300 group-hover:bg-[#f1e7e3] ${soldOut ? 'opacity-70' : ''}`}
      />
      <div className="mt-4 px-1">
        <h3 className="text-xl text-ink decoration-gold decoration-1 underline-offset-4 group-hover:underline">
          {product.name}
        </h3>
        {product.material && <p className="mt-1 line-clamp-1 text-sm text-muted">{product.material}</p>}
        <div className="mt-2 flex items-baseline justify-between gap-3">
          <p className="font-medium text-ink">{formatPrice(product.price)}</p>
          {product.stockQuantity <= 5 && <StockNote stock={product.stockQuantity} className="text-sm" />}
        </div>
      </div>
    </Link>
  );
}
