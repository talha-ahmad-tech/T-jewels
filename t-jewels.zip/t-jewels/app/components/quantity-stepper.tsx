'use client';

type QuantityStepperProps = {
  value: number;
  max: number;
  min?: number;
  label: string;
  onChange: (value: number) => void;
};

export function QuantityStepper({ value, max, min = 1, label, onChange }: QuantityStepperProps) {
  const buttonClass =
    'flex h-10 w-10 items-center justify-center rounded-full text-lg text-ink transition-colors hover:bg-pearl disabled:cursor-not-allowed disabled:text-muted/40 disabled:hover:bg-transparent';

  return (
    <div role="group" aria-label={label} className="inline-flex items-center rounded-full border border-line bg-white">
      <button type="button" className={buttonClass} onClick={() => onChange(value - 1)} disabled={value <= min} aria-label="Decrease quantity">
        −
      </button>
      <output aria-live="polite" className="w-8 text-center tabular-nums">
        {value}
      </output>
      <button type="button" className={buttonClass} onClick={() => onChange(value + 1)} disabled={value >= max} aria-label="Increase quantity">
        +
      </button>
    </div>
  );
}
