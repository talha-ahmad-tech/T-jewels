type FieldProps = {
  label: string;
  name: string;
  type?: string;
  multiline?: boolean;
  hint?: string;
  defaultValue?: string;
  autoComplete?: string;
  placeholder?: string;
  required?: boolean;
  minLength?: number;
};

const inputClass =
  'mt-1.5 block w-full rounded-md border border-line bg-white px-3.5 py-2.5 text-base text-ink placeholder:text-muted/70 transition-colors focus:border-gold-ink focus:outline-none';

export function Field({ label, name, type = 'text', multiline = false, hint, ...inputProps }: FieldProps) {
  const id = `field-${name}`;
  const hintId = hint ? `${id}-hint` : undefined;

  return (
    <div>
      <label htmlFor={id} className="text-sm font-medium text-ink">
        {label}
      </label>
      {multiline ? (
        <textarea id={id} name={name} rows={3} aria-describedby={hintId} className={inputClass} {...inputProps} />
      ) : (
        <input id={id} name={name} type={type} aria-describedby={hintId} className={inputClass} {...inputProps} />
      )}
      {hint && (
        <p id={hintId} className="mt-1.5 text-xs text-muted">
          {hint}
        </p>
      )}
    </div>
  );
}
