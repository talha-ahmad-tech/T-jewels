'use client';

import Link from 'next/link';
import { useState } from 'react';
import { MAX_PER_ITEM, type CartProduct } from '@/lib/cart';
import { addToCart, useCart } from '@/lib/cart-store';
import { QuantityStepper } from './quantity-stepper';
import { buttonStyles, linkStyles } from './styles';

export function AddToBag({ product }: { product: CartProduct }) {
  const { items } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  const inBag = items.find((item) => item.productId === product.productId)?.quantity ?? 0;
  const available = Math.max(Math.min(product.maxQuantity, MAX_PER_ITEM) - inBag, 0);
  const chosen = Math.min(quantity, Math.max(available, 1));

  if (product.maxQuantity <= 0) {
    return (
      <button type="button" disabled className={`${buttonStyles.primary} w-full sm:w-auto`}>
        Sold out
      </button>
    );
  }

  const handleAdd = () => {
    addToCart(product, chosen);
    setQuantity(1);
    setAdded(true);
  };

  return (
    <div>
      <div className="flex flex-wrap items-center gap-3">
        <QuantityStepper value={chosen} max={Math.max(available, 1)} label="Quantity" onChange={setQuantity} />
        <button type="button" onClick={handleAdd} disabled={available === 0} className={`${buttonStyles.primary} flex-1 sm:flex-none sm:px-10`}>
          Add to bag
        </button>
      </div>
      <p aria-live="polite" className="mt-3 min-h-6 text-sm text-muted">
        {available === 0 && !added && 'You have every available piece in your bag.'}
        {added && (
          <>
            Added to your bag.{' '}
            <Link href="/bag" className={linkStyles}>
              View bag
            </Link>
          </>
        )}
      </p>
    </div>
  );
}
