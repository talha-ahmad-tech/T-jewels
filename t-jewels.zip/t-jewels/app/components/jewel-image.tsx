import Image from 'next/image';

type JewelImageProps = {
  src: string | null;
  alt: string;
  sizes: string;
  className?: string;
  imageClassName?: string;
  eager?: boolean;
};

export function JewelImage({ src, alt, sizes, className = '', imageClassName = 'p-[9%] pt-[16%]', eager = false }: JewelImageProps) {
  return (
    <div className={`arch relative overflow-hidden ${className}`}>
      {src ? (
        <Image
          src={src}
          alt={alt}
          fill
          sizes={sizes}
          loading={eager ? 'eager' : 'lazy'}
          unoptimized={!src.startsWith('/')}
          className={`object-contain ${imageClassName}`}
        />
      ) : (
        <span className="absolute inset-0 flex items-center justify-center font-display text-5xl text-gold-ink/40" aria-hidden="true">
          T
        </span>
      )}
    </div>
  );
}
