'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useActionState, useSyncExternalStore } from 'react';
import { placeOrder, type CheckoutState } from '@/app/actions/orders';
import { deliveryFeeFor, FREE_DELIVERY_THRESHOLD, MAX_PER_ITEM } from '@/lib/cart';
import { clearCart, removeFromCart, updateCartQuantity, useCart } from '@/lib/cart-store';
import { formatPrice, pluralize } from '@/lib/format';
import { Field } from './field';
import { JewelImage } from './jewel-image';
import { QuantityStepper } from './quantity-stepper';
import { buttonStyles, linkStyles } from './styles';

type BagViewProps = {
  user: { name: string } | null;
};

const subscribeNothing = () => () => {};

export function BagView({ user }: BagViewProps) {
  const router = useRouter();
  const { items, count, subtotal } = useCart();
  const hydrated = useSyncExternalStore(subscribeNothing, () => true, () => false);
  const deliveryFee = deliveryFeeFor(subtotal);

  const [state, formAction, pending] = useActionState(async (previous: CheckoutState, formData: FormData) => {
    const result = await placeOrder(previous, formData);

    if (result?.orderId) {
      clearCart();
      router.push(`/account?order=${result.orderId}`);
    }

    return result;
  }, undefined);

  if (!hydrated) {
    return <div className="h-64 animate-pulse rounded-md bg-pearl motion-reduce:animate-none" aria-hidden="true" />;
  }

  if (items.length === 0) {
    return (
      <div className="rounded-md bg-pearl px-6 py-16 text-center">
        <h2 className="text-3xl">Your bag is empty</h2>
        <p className="mx-auto mt-3 max-w-sm text-muted">Pieces you add stay here on this device until you place your order.</p>
        <Link href="/products" className={`${buttonStyles.primary} mt-8`}>
          Shop all jewellery
        </Link>
      </div>
    );
  }

  return (
    <div className="grid gap-10 lg:grid-cols-[minmax(0,1fr)_24rem] lg:gap-14">
      <section aria-labelledby="bag-items">
        <h2 id="bag-items" className="sr-only">
          Pieces in your bag
        </h2>
        <ul className="divide-y divide-line border-y border-line">
          {items.map((item) => (
            <li key={item.productId} className="flex gap-4 py-5 sm:gap-6">
              <Link href={`/products/${item.slug}`} className="w-20 shrink-0 sm:w-24" tabIndex={-1} aria-hidden="true">
                <JewelImage src={item.picture} alt="" sizes="96px" className="aspect-[4/5] bg-pearl" imageClassName="p-2 pt-4" />
              </Link>
              <div className="flex min-w-0 flex-1 flex-col">
                <div className="flex items-start justify-between gap-3">
                  <Link href={`/products/${item.slug}`} className="font-display text-xl leading-tight text-ink hover:underline">
                    {item.name}
                  </Link>
                  <p className="shrink-0 font-medium">{formatPrice(item.price * item.quantity)}</p>
                </div>
                <p className="mt-1 text-sm text-muted">{formatPrice(item.price)} each</p>
                <div className="mt-auto flex flex-wrap items-center justify-between gap-3 pt-3">
                  <QuantityStepper
                    value={item.quantity}
                    max={Math.min(item.maxQuantity, MAX_PER_ITEM)}
                    label={`Quantity of ${item.name}`}
                    onChange={(quantity) => updateCartQuantity(item.productId, quantity)}
                  />
                  <button type="button" onClick={() => removeFromCart(item.productId)} className="text-sm text-muted underline underline-offset-4 hover:text-ruby">
                    Remove<span className="sr-only"> {item.name}</span>
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </section>

      <aside aria-labelledby="bag-summary" className="h-fit rounded-md bg-pearl p-6 sm:p-8">
        <h2 id="bag-summary" className="text-2xl">
          Order summary
        </h2>
        <dl className="mt-5 space-y-3 text-[0.95rem]">
          <div className="flex justify-between gap-4">
            <dt className="text-muted">Subtotal ({pluralize(count, 'piece')})</dt>
            <dd>{formatPrice(subtotal)}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-muted">Delivery</dt>
            <dd>{deliveryFee > 0 ? formatPrice(deliveryFee) : 'Free'}</dd>
          </div>
          <div className="flex justify-between gap-4 border-t border-line pt-3 text-lg font-medium">
            <dt>Total</dt>
            <dd>{formatPrice(subtotal + deliveryFee)}</dd>
          </div>
        </dl>
        {deliveryFee > 0 && (
          <p className="mt-3 text-sm text-muted">Add {formatPrice(FREE_DELIVERY_THRESHOLD - subtotal)} more for free delivery.</p>
        )}

        {user ? (
          <form action={formAction} className="mt-7 space-y-4 border-t border-line pt-6">
            <h3 className="font-sans text-base font-medium">Delivery details</h3>
            <input
              type="hidden"
              name="items"
              value={JSON.stringify(items.map(({ productId, quantity }) => ({ productId, quantity })))}
            />
            <Field label="Full name" name="name" autoComplete="name" defaultValue={state?.fields?.name ?? user.name} required />
            <Field label="Phone" name="phone" type="tel" autoComplete="tel" placeholder="0300 1234567" defaultValue={state?.fields?.phone} required />
            <Field label="Address" name="address" multiline autoComplete="street-address" defaultValue={state?.fields?.address} required />
            <Field label="City" name="city" autoComplete="address-level2" defaultValue={state?.fields?.city} required />
            {state?.error && (
              <p role="alert" className="rounded-md bg-ruby/5 px-3.5 py-2.5 text-sm text-ruby">
                {state.error}
              </p>
            )}
            <button type="submit" disabled={pending} className={`${buttonStyles.primary} w-full`}>
              {pending ? 'Placing order…' : 'Place order'}
            </button>
            <p className="text-center text-sm text-muted">You pay in cash when your order arrives.</p>
          </form>
        ) : (
          <div className="mt-7 space-y-3 border-t border-line pt-6">
            <p className="text-sm text-muted">Sign in to place your order. Your bag stays saved while you do.</p>
            <Link href="/login?next=/bag" className={`${buttonStyles.primary} w-full`}>
              Sign in to check out
            </Link>
            <p className="text-center text-sm text-muted">
              New here?{' '}
              <Link href="/register?next=/bag" className={linkStyles}>
                Create an account
              </Link>
            </p>
          </div>
        )}
      </aside>
    </div>
  );
}
