'use client';

import Link from 'next/link';
import { useActionState } from 'react';
import { signIn, signUp, type AuthState } from '@/app/actions/auth';
import { Field } from './field';
import { buttonStyles, linkStyles } from './styles';

type AuthFormProps = {
  mode: 'signin' | 'signup';
  next?: string;
};

export function AuthForm({ mode, next }: AuthFormProps) {
  const isSignUp = mode === 'signup';
  const [state, formAction, pending] = useActionState<AuthState, FormData>(isSignUp ? signUp : signIn, undefined);
  const nextQuery = next ? `?next=${encodeURIComponent(next)}` : '';

  return (
    <form action={formAction} className="space-y-5">
      {next && <input type="hidden" name="next" value={next} />}
      {isSignUp && <Field label="Full name" name="name" autoComplete="name" defaultValue={state?.fields?.name} required />}
      <Field label="Email" name="email" type="email" autoComplete="email" defaultValue={state?.fields?.email} required />
      <Field
        label="Password"
        name="password"
        type="password"
        autoComplete={isSignUp ? 'new-password' : 'current-password'}
        hint={isSignUp ? 'At least 8 characters.' : undefined}
        minLength={isSignUp ? 8 : undefined}
        required
      />
      {state?.error && (
        <p role="alert" className="rounded-md bg-ruby/5 px-3.5 py-2.5 text-sm text-ruby">
          {state.error}
        </p>
      )}
      <button type="submit" disabled={pending} className={`${buttonStyles.primary} w-full`}>
        {pending ? (isSignUp ? 'Creating account…' : 'Signing in…') : isSignUp ? 'Create account' : 'Sign in'}
      </button>
      <p className="text-center text-sm text-muted">
        {isSignUp ? 'Already have an account? ' : 'New to T Jewels? '}
        <Link href={`${isSignUp ? '/login' : '/register'}${nextQuery}`} className={linkStyles}>
          {isSignUp ? 'Sign in' : 'Create an account'}
        </Link>
      </p>
    </form>
  );
}
