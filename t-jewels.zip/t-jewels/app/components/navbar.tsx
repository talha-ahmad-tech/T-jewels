'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';
import { signOut } from '@/app/actions/auth';
import { useCart } from '@/lib/cart-store';
import { BagIcon, CloseIcon, MenuIcon, UserIcon } from './icons';
import { Logo } from './logo';
import { containerStyles } from './styles';

const navigation = [
  { label: 'Shop', href: '/products' },
  { label: 'Collections', href: '/collections' },
];

type NavbarProps = {
  user: { name: string } | null;
};

export default function Navbar({ user }: NavbarProps) {
  const pathname = usePathname();
  const { count } = useCart();
  const [menuOpenOn, setMenuOpenOn] = useState<string | null>(null);
  const menuOpen = menuOpenOn === pathname;
  const firstName = user?.name.split(' ')[0];
  const bagLabel = count > 0 ? `Bag, ${count} ${count === 1 ? 'item' : 'items'}` : 'Bag';

  const isActive = (href: string) => pathname === href || pathname.startsWith(`${href}/`);

  return (
    <>
      <p className="velvet px-4 py-2 text-center text-[0.8125rem] text-gold-light">
        Cash on delivery across Pakistan. Free delivery on orders over PKR 10,000.
      </p>
      <header className="sticky top-0 z-30 border-b border-line bg-white/95 backdrop-blur">
        <div className={`${containerStyles} flex h-16 items-center justify-between gap-6 sm:h-[4.5rem]`}>
          <Logo />

          <nav aria-label="Main" className="hidden md:block">
            <ul className="flex items-center gap-9">
              {navigation.map(({ label, href }) => (
                <li key={href}>
                  <Link
                    href={href}
                    aria-current={isActive(href) ? 'page' : undefined}
                    className={`border-b py-1 text-[0.95rem] transition-colors ${
                      isActive(href) ? 'border-gold-ink text-ink' : 'border-transparent text-muted hover:text-ink'
                    }`}
                  >
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div className="flex items-center gap-1 sm:gap-2">
            <Link
              href={user ? '/account' : '/login'}
              className="hidden items-center gap-2 rounded-full px-3 py-2 text-[0.95rem] text-ink transition-colors hover:bg-pearl sm:inline-flex"
            >
              <UserIcon className="h-5 w-5" />
              <span className="max-w-32 truncate">{user ? firstName : 'Sign in'}</span>
            </Link>
            <Link
              href="/bag"
              aria-label={bagLabel}
              className="relative inline-flex items-center gap-2 rounded-full px-3 py-2 text-[0.95rem] text-ink transition-colors hover:bg-pearl"
            >
              <BagIcon className="h-5 w-5" />
              <span className="hidden sm:inline">Bag</span>
              {count > 0 && (
                <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-velvet px-1.5 text-xs font-medium text-white tabular-nums">
                  {count}
                </span>
              )}
            </Link>
            <button
              type="button"
              className="inline-flex h-10 w-10 items-center justify-center rounded-full text-ink transition-colors hover:bg-pearl md:hidden"
              aria-expanded={menuOpen}
              aria-controls="mobile-menu"
              onClick={() => setMenuOpenOn(menuOpen ? null : pathname)}
            >
              {menuOpen ? <CloseIcon className="h-6 w-6" /> : <MenuIcon className="h-6 w-6" />}
              <span className="sr-only">{menuOpen ? 'Close menu' : 'Open menu'}</span>
            </button>
          </div>
        </div>

        {menuOpen && (
          <nav id="mobile-menu" aria-label="Mobile" className="border-t border-line bg-white md:hidden">
            <ul className={`${containerStyles} py-3`}>
              {navigation.map(({ label, href }) => (
                <li key={href}>
                  <Link
                    href={href}
                    aria-current={isActive(href) ? 'page' : undefined}
                    className={`block py-3 font-display text-2xl ${isActive(href) ? 'text-velvet' : 'text-ink'}`}
                    onClick={() => setMenuOpenOn(null)}
                  >
                    {label}
                  </Link>
                </li>
              ))}
              <li className="mt-2 border-t border-line pt-3">
                <Link href={user ? '/account' : '/login'} className="block py-2 text-ink" onClick={() => setMenuOpenOn(null)}>
                  {user ? 'Your account' : 'Sign in'}
                </Link>
              </li>
              {user && (
                <li>
                  <form action={signOut}>
                    <button type="submit" className="py-2 text-muted">
                      Sign out
                    </button>
                  </form>
                </li>
              )}
            </ul>
          </nav>
        )}
      </header>
    </>
  );
}
