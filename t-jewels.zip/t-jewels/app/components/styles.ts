export const buttonStyles = {
  primary:
    'inline-flex items-center justify-center gap-2 rounded-full bg-velvet px-6 py-3 font-medium text-white transition-colors hover:bg-velvet-soft disabled:cursor-not-allowed disabled:opacity-60',
  secondary:
    'inline-flex items-center justify-center gap-2 rounded-full border border-velvet/30 px-6 py-3 font-medium text-velvet transition-colors hover:border-velvet hover:bg-velvet hover:text-white',
  gold:
    'inline-flex items-center justify-center gap-2 rounded-full bg-gold-light px-6 py-3 font-medium text-velvet-deep transition-colors hover:bg-white',
};

export const linkStyles =
  'font-medium text-gold-ink underline decoration-gold/60 underline-offset-4 transition-colors hover:decoration-gold-ink';

export const containerStyles = 'mx-auto w-full max-w-6xl px-4 sm:px-6 lg:px-8';
