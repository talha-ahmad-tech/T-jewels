export function StockNote({ stock, className = '' }: { stock: number; className?: string }) {
  if (stock <= 0) {
    return <p className={`text-ruby ${className}`}>Sold out</p>;
  }

  if (stock <= 5) {
    return <p className={`text-gold-ink ${className}`}>Only {stock} left</p>;
  }

  return <p className={`text-emerald ${className}`}>In stock</p>;
}
