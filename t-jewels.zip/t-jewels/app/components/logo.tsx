import Link from 'next/link';

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <path d="M12 62V28C12 16 22 9 32 3c10 6 20 13 20 25v34Z" fill="#4b1824" />
      <path d="M15 60V28.5C15 18.5 23.4 12.3 32 7c8.6 5.3 17 11.5 17 21.5V60" fill="none" stroke="#c9a45c" strokeWidth="1.2" />
      <path d="M21 31l6.5-7.5h9L43 31l-11 15Z" fill="#e2c98f" />
      <path d="M21 31h22M27.5 23.5 32 31l4.5-7.5M32 31v15" fill="none" stroke="#4b1824" strokeWidth="1" strokeLinejoin="round" />
    </svg>
  );
}

export function Logo({ tone = 'dark' }: { tone?: 'dark' | 'light' }) {
  return (
    <Link href="/" className="group inline-flex items-center gap-2.5" aria-label="T Jewels home">
      <LogoMark className="h-10 w-10 shrink-0" />
      <span className={`font-display text-[1.65rem] leading-none tracking-tight ${tone === 'light' ? 'text-gold-light' : 'text-velvet'}`}>
        T Jewels
      </span>
    </Link>
  );
}
