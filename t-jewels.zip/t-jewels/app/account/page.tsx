import type { Metadata } from 'next';
import Link from 'next/link';
import { redirect } from 'next/navigation';
import { formatDate, formatPrice } from '@/lib/format';
import { getOrdersForUser } from '@/lib/queries';
import { getCurrentUser } from '@/lib/session';
import { signOut } from '../actions/auth';
import { buttonStyles, linkStyles } from '../components/styles';

export const metadata: Metadata = {
  title: 'Your account',
};

const statusLabels: Record<string, string> = {
  placed: 'Placed',
  confirmed: 'Confirmed',
  shipped: 'On its way',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
};

type AccountPageProps = {
  searchParams: Promise<{ order?: string | string[] }>;
};

export default async function AccountPage({ searchParams }: AccountPageProps) {
  const user = await getCurrentUser();

  if (!user) {
    redirect('/login?next=/account');
  }

  const [{ order }, orders] = await Promise.all([searchParams, getOrdersForUser(user.id)]);
  const placed = orders.find((item) => String(item.id) === order);

  return (
    <div className="mx-auto w-full max-w-4xl px-4 pb-20 pt-10 sm:px-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-4xl sm:text-5xl">Hello, {user.name.split(' ')[0]}</h1>
          <p className="mt-2 text-muted">Signed in as {user.email}</p>
        </div>
        <form action={signOut}>
          <button type="submit" className={buttonStyles.secondary}>
            Sign out
          </button>
        </form>
      </div>

      {placed && (
        <div role="status" className="mt-8 rounded-md border-l-2 border-emerald bg-emerald/5 px-5 py-4">
          <p className="font-medium text-emerald">Thank you. Order #{placed.id} is placed.</p>
          <p className="mt-1 text-sm text-muted">
            You will pay {formatPrice(placed.total)} in cash when it arrives in {placed.city}.
          </p>
        </div>
      )}

      <section aria-labelledby="orders-heading" className="mt-12">
        <h2 id="orders-heading" className="text-3xl">
          Your orders
        </h2>

        {orders.length > 0 ? (
          <ul className="mt-6 space-y-5">
            {orders.map((item) => (
              <li key={item.id} className="rounded-md border border-line p-5 sm:p-6">
                <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
                  <h3 className="text-2xl">Order #{item.id}</h3>
                  <p className="text-sm text-muted">{formatDate(item.createdAt)}</p>
                </div>
                <p className="mt-1 text-sm">
                  <span className="font-medium text-gold-ink">{statusLabels[item.status] ?? item.status}</span>
                  <span className="text-muted">, delivering to {item.city}</span>
                </p>
                <ul className="mt-4 space-y-1.5 text-[0.95rem]">
                  {item.items.map((line, index) => (
                    <li key={`${item.id}-${index}`} className="flex justify-between gap-4">
                      <span>
                        {line.productSlug ? (
                          <Link href={`/products/${line.productSlug}`} className="hover:underline">
                            {line.productName}
                          </Link>
                        ) : (
                          line.productName
                        )}
                        <span className="text-muted"> × {line.quantity}</span>
                      </span>
                      <span className="shrink-0">{formatPrice(line.unitPrice * line.quantity)}</span>
                    </li>
                  ))}
                </ul>
                <div className="mt-4 flex justify-between gap-4 border-t border-line pt-3">
                  <span className="text-sm text-muted">
                    {item.deliveryFee > 0 ? `Includes ${formatPrice(item.deliveryFee)} delivery` : 'Free delivery'}
                  </span>
                  <span className="font-medium">{formatPrice(item.total)}</span>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <div className="mt-6 rounded-md bg-pearl px-6 py-12 text-center">
            <p className="font-display text-2xl">No orders yet</p>
            <p className="mt-2 text-muted">Orders you place will show up here with their status.</p>
            <Link href="/products" className={`${buttonStyles.primary} mt-6`}>
              Shop all jewellery
            </Link>
          </div>
        )}
      </section>

      <p className="mt-10 text-sm text-muted">
        Looking for something?{' '}
        <Link href="/collections" className={linkStyles}>
          Browse collections
        </Link>
      </p>
    </div>
  );
}
