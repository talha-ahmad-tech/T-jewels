import type { CSSProperties } from 'react';
import Link from 'next/link';
import { formatPrice, pluralize } from '@/lib/format';
import { getCategories, getFeaturedProducts, getNewArrivals, getProducts } from '@/lib/queries';
import { JewelImage } from './components/jewel-image';
import { ProductCard } from './components/product-card';
import { buttonStyles, containerStyles, linkStyles } from './components/styles';

const orderingSteps = [
  {
    title: 'Choose your pieces',
    text: 'Add rings, earrings or a full bridal set to your bag. Your bag is saved on this device.',
  },
  {
    title: 'Place your order',
    text: 'Sign in, then add your phone number and delivery address. It takes about a minute.',
  },
  {
    title: 'Pay on delivery',
    text: 'Pay in cash when your order arrives. Delivery is free on orders over PKR 10,000.',
  },
];

export default async function HomePage() {
  const [featured, categories, newArrivals, bridalSets] = await Promise.all([
    getFeaturedProducts(3),
    getCategories(),
    getNewArrivals(4),
    getProducts({ category: 'bridal' }),
  ]);

  const bridal = bridalSets[0];

  return (
    <>
      <section className={`${containerStyles} grid gap-10 pb-16 pt-10 md:pt-14 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:items-center lg:gap-14 lg:pb-24`}>
        <div>
          <h1 className="text-[2.6rem] sm:text-6xl lg:text-[4.1rem]">Jewellery for every day and every celebration</h1>
          <p className="mt-6 max-w-md text-lg leading-8 text-muted">
            Rings, earrings, necklaces and bridal sets in sterling silver and gold vermeil, delivered anywhere in Pakistan.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/products" className={buttonStyles.primary}>
              Shop all jewellery
            </Link>
            <Link href="/products?category=bridal" className={buttonStyles.secondary}>
              See bridal sets
            </Link>
          </div>
        </div>

        {featured.length > 0 && (
          <div className="velvet rounded-md px-3 pb-6 pt-8 sm:px-8 sm:pb-8 sm:pt-10">
            <ul className="grid grid-cols-3 items-end gap-3 sm:gap-6">
              {featured.map((product, index) => (
                <li key={product.id} className="rise" style={{ '--delay': `${0.1 + index * 0.15}s` } as CSSProperties}>
                  <Link href={`/products/${product.slug}`} className="group block text-center">
                    <div className="arch bg-gold/70 p-[1.5px]">
                      <JewelImage
                        src={product.picture}
                        alt={product.name}
                        sizes="(min-width: 1024px) 18vw, 30vw"
                        className={`${index === 1 ? 'aspect-[3/5]' : 'aspect-[3/4]'} bg-velvet-deep transition-colors duration-300 group-hover:bg-[#40131f]`}
                        imageClassName="p-[2%] pt-[14%]"
                        eager
                      />
                    </div>
                    <p className="mt-3 font-display text-[0.95rem] leading-tight text-gold-light group-hover:underline sm:text-lg">
                      {product.name}
                    </p>
                    <p className="mt-1 text-xs text-white/70 sm:text-sm">{formatPrice(product.price)}</p>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}
      </section>

      <section className="border-t border-line">
        <div className={`${containerStyles} py-16`}>
          <div className="flex items-end justify-between gap-4">
            <h2 className="text-3xl sm:text-4xl">Shop by collection</h2>
            <Link href="/collections" className={`${linkStyles} shrink-0 text-sm`}>
              All collections
            </Link>
          </div>
          <ul className="-mx-4 mt-8 flex snap-x scroll-px-4 gap-4 overflow-x-auto px-4 pb-2 sm:mx-0 sm:grid sm:grid-cols-5 sm:overflow-visible sm:px-0 sm:pb-0">
            {categories.map((category) => (
              <li key={category.id} className="w-36 shrink-0 snap-start sm:w-auto">
                <Link href={`/products?category=${category.slug}`} className="group block">
                  <JewelImage src={category.picture} alt="" sizes="(min-width: 640px) 18vw, 144px" className="aspect-[4/5] bg-pearl" />
                  <p className="mt-3 font-display text-xl leading-tight group-hover:underline">{category.name}</p>
                  <p className="mt-1 text-sm text-muted">{pluralize(category.productCount, 'piece')}</p>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className={`${containerStyles} pb-20`}>
        <div className="flex items-end justify-between gap-4">
          <h2 className="text-3xl sm:text-4xl">New in</h2>
          <Link href="/products" className={`${linkStyles} shrink-0 text-sm`}>
            Shop all jewellery
          </Link>
        </div>
        <ul className="mt-8 grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6 lg:grid-cols-4">
          {newArrivals.map((product) => (
            <li key={product.id}>
              <ProductCard product={product} />
            </li>
          ))}
        </ul>
      </section>

      {bridal && (
        <section className="velvet text-white">
          <div className={`${containerStyles} grid items-center gap-10 py-16 md:grid-cols-2 md:py-20`}>
            <div>
              <h2 className="text-4xl text-gold-light sm:text-5xl">Bridal sets for mehndi, baraat and walima</h2>
              <p className="mt-5 max-w-md text-lg leading-8 text-white/75">
                Necklaces with matching jhumkas and earrings, made to be worn together through the wedding week.
              </p>
              <Link href="/products?category=bridal" className={`${buttonStyles.gold} mt-8`}>
                See bridal sets
              </Link>
            </div>
            <Link href={`/products/${bridal.slug}`} className="group mx-auto block w-full max-w-sm text-center">
              <div className="arch bg-gold/70 p-[1.5px]">
                <JewelImage src={bridal.picture} alt={bridal.name} sizes="(min-width: 768px) 384px, 90vw" className="aspect-[4/5] bg-velvet-deep" />
              </div>
              <p className="mt-4 font-display text-xl text-gold-light group-hover:underline">{bridal.name}</p>
              <p className="mt-1 text-sm text-white/70">{formatPrice(bridal.price)}</p>
            </Link>
          </div>
        </section>
      )}

      <section className={`${containerStyles} py-16 md:py-20`}>
        <h2 className="text-3xl sm:text-4xl">How ordering works</h2>
        <ol className="mt-8 grid gap-8 md:grid-cols-3">
          {orderingSteps.map((step, index) => (
            <li key={step.title} className="border-t border-line pt-5">
              <span className="font-display text-3xl text-gold-ink">{index + 1}</span>
              <h3 className="mt-2 text-2xl">{step.title}</h3>
              <p className="mt-2 max-w-xs text-muted">{step.text}</p>
            </li>
          ))}
        </ol>
      </section>
    </>
  );
}
