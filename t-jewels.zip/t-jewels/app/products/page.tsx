import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { pluralize } from '@/lib/format';
import { getCategories, getCategory, getProducts } from '@/lib/queries';
import { shopUrl } from '@/lib/shop-url';
import { isSortOption } from '@/lib/types';
import { ProductCard } from '../components/product-card';
import { ShopToolbar } from '../components/shop-toolbar';
import { buttonStyles, containerStyles } from '../components/styles';

type ProductsPageProps = {
  searchParams: Promise<{ category?: string | string[]; q?: string | string[]; sort?: string | string[] }>;
};

function readParam(value: string | string[] | undefined) {
  return typeof value === 'string' ? value : undefined;
}

export async function generateMetadata({ searchParams }: ProductsPageProps): Promise<Metadata> {
  const slug = readParam((await searchParams).category);
  const category = slug ? await getCategory(slug) : null;
  return { title: category?.name ?? 'All jewellery' };
}

export default async function ProductsPage({ searchParams }: ProductsPageProps) {
  const params = await searchParams;
  const category = readParam(params.category);
  const search = readParam(params.q)?.trim().slice(0, 60) ?? '';
  const sortParam = readParam(params.sort);
  const sort = isSortOption(sortParam) ? sortParam : 'newest';

  const [categories, products] = await Promise.all([getCategories(), getProducts({ category, search, sort })]);
  const current = categories.find((item) => item.slug === category);

  if (category && !current) {
    notFound();
  }

  const chipClass = (active: boolean) =>
    `inline-flex whitespace-nowrap rounded-full px-4 py-2 text-sm transition-colors ${
      active ? 'bg-velvet text-white' : 'text-ink hover:bg-pearl'
    }`;

  return (
    <div className={`${containerStyles} pb-20 pt-10`}>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-4xl sm:text-5xl">{current?.name ?? 'All jewellery'}</h1>
          <p className="mt-3 max-w-xl text-muted">
            {current?.description ?? 'Every piece in the shop, from everyday studs to sets for the wedding week.'}
          </p>
        </div>
        <p className="text-sm text-muted">{pluralize(products.length, 'piece')}</p>
      </div>

      <div className="mt-8 flex flex-col gap-4 border-y border-line py-4 lg:flex-row lg:items-center lg:justify-between">
        <nav aria-label="Collections">
          <ul className="-mx-4 flex gap-1 overflow-x-auto px-4 lg:mx-0 lg:flex-wrap lg:px-0">
            <li>
              <Link href={shopUrl({ search, sort })} aria-current={!current ? 'page' : undefined} className={chipClass(!current)}>
                All
              </Link>
            </li>
            {categories.map((item) => (
              <li key={item.id}>
                <Link
                  href={shopUrl({ category: item.slug, search, sort })}
                  aria-current={item.slug === current?.slug ? 'page' : undefined}
                  className={chipClass(item.slug === current?.slug)}
                >
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <ShopToolbar category={current?.slug} search={search} sort={sort} />
      </div>

      {products.length > 0 ? (
        <ul className="mt-10 grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6 lg:grid-cols-4">
          {products.map((product) => (
            <li key={product.id}>
              <ProductCard product={product} />
            </li>
          ))}
        </ul>
      ) : (
        <div className="mt-12 rounded-md bg-pearl px-6 py-16 text-center">
          <h2 className="text-3xl">{search ? `No pieces match “${search}”` : 'No pieces here yet'}</h2>
          <p className="mx-auto mt-3 max-w-md text-muted">
            {search ? 'Try a different word, or clear the search to see every piece.' : 'Browse the full shop while new pieces are added.'}
          </p>
          <Link href={search ? shopUrl({ category, sort }) : '/products'} className={`${buttonStyles.primary} mt-8`}>
            {search ? 'Clear search' : 'Shop all jewellery'}
          </Link>
        </div>
      )}
    </div>
  );
}
