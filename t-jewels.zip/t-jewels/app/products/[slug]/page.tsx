import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { formatPrice } from '@/lib/format';
import { getProductBySlug, getRelatedProducts } from '@/lib/queries';
import { AddToBag } from '../../components/add-to-bag';
import { JewelImage } from '../../components/jewel-image';
import { ProductCard } from '../../components/product-card';
import { StockNote } from '../../components/stock-note';
import { containerStyles, linkStyles } from '../../components/styles';

type ProductPageProps = {
  params: Promise<{ slug: string }>;
};

export async function generateMetadata({ params }: ProductPageProps): Promise<Metadata> {
  const product = await getProductBySlug((await params).slug);

  if (!product) {
    return { title: 'Piece not found' };
  }

  return { title: product.name, description: product.description ?? undefined };
}

export default async function ProductPage({ params }: ProductPageProps) {
  const product = await getProductBySlug((await params).slug);

  if (!product) {
    notFound();
  }

  const related = await getRelatedProducts(product, 4);

  return (
    <div className={`${containerStyles} pb-20 pt-8`}>
      <nav aria-label="Breadcrumb" className="text-sm text-muted">
        <ol className="flex flex-wrap items-center gap-2">
          <li>
            <Link href="/products" className="hover:text-ink">
              Shop
            </Link>
          </li>
          {product.categorySlug && (
            <>
              <li aria-hidden="true">/</li>
              <li>
                <Link href={`/products?category=${product.categorySlug}`} className="hover:text-ink">
                  {product.categoryName}
                </Link>
              </li>
            </>
          )}
          <li aria-hidden="true">/</li>
          <li aria-current="page" className="text-ink">
            {product.name}
          </li>
        </ol>
      </nav>

      <div className="mt-6 grid gap-10 md:grid-cols-2 md:gap-14">
        <JewelImage
          src={product.picture}
          alt={product.name}
          sizes="(min-width: 768px) 45vw, 100vw"
          className="aspect-[4/5] w-full bg-pearl"
          imageClassName="p-[10%] pt-[18%]"
          eager
        />

        <div className="md:pt-8">
          <h1 className="text-4xl sm:text-5xl">{product.name}</h1>
          <p className="mt-4 text-2xl">{formatPrice(product.price)}</p>
          <StockNote stock={product.stockQuantity} className="mt-2 text-sm font-medium" />
          {product.description && <p className="mt-6 max-w-prose text-lg leading-8 text-muted">{product.description}</p>}

          <div className="mt-8">
            <AddToBag
              product={{
                productId: product.id,
                slug: product.slug,
                name: product.name,
                price: product.price,
                picture: product.picture,
                maxQuantity: product.stockQuantity,
              }}
            />
          </div>

          <dl className="mt-8 divide-y divide-line border-y border-line text-[0.95rem]">
            {product.material && (
              <div className="grid grid-cols-[7rem_1fr] gap-4 py-3.5">
                <dt className="text-muted">Material</dt>
                <dd>{product.material}</dd>
              </div>
            )}
            {product.categorySlug && (
              <div className="grid grid-cols-[7rem_1fr] gap-4 py-3.5">
                <dt className="text-muted">Collection</dt>
                <dd>
                  <Link href={`/products?category=${product.categorySlug}`} className={linkStyles}>
                    {product.categoryName}
                  </Link>
                </dd>
              </div>
            )}
            <div className="grid grid-cols-[7rem_1fr] gap-4 py-3.5">
              <dt className="text-muted">Delivery</dt>
              <dd>Cash on delivery anywhere in Pakistan. Free on orders over PKR 10,000.</dd>
            </div>
          </dl>
        </div>
      </div>

      {related.length > 0 && (
        <section aria-labelledby="related-heading" className="mt-20 border-t border-line pt-12">
          <h2 id="related-heading" className="text-3xl sm:text-4xl">
            You may also like
          </h2>
          <ul className="mt-8 grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6 lg:grid-cols-4">
            {related.map((item) => (
              <li key={item.id}>
                <ProductCard product={item} />
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
