import { containerStyles } from '../components/styles';

export default function Loading() {
  return (
    <div className={`${containerStyles} pb-20 pt-10`} aria-busy="true" aria-label="Loading jewellery">
      <div className="h-12 w-64 rounded-md bg-pearl" />
      <div className="mt-4 h-5 w-96 max-w-full rounded-md bg-pearl" />
      <ul className="mt-14 grid grid-cols-2 gap-x-4 gap-y-10 sm:gap-x-6 lg:grid-cols-4">
        {Array.from({ length: 8 }, (_, index) => (
          <li key={index}>
            <div className="arch aspect-[4/5] bg-pearl motion-safe:animate-pulse" />
            <div className="mt-4 h-5 w-3/4 rounded-md bg-pearl" />
            <div className="mt-2 h-4 w-1/3 rounded-md bg-pearl" />
          </li>
        ))}
      </ul>
    </div>
  );
}
