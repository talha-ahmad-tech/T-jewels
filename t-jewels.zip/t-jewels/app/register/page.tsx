import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { safeNextPath } from '@/lib/next-path';
import { getCurrentUser } from '@/lib/session';
import { AuthForm } from '../components/auth-form';
import { AuthLayout } from '../components/auth-layout';

export const metadata: Metadata = {
  title: 'Create an account',
};

type RegisterPageProps = {
  searchParams: Promise<{ next?: string | string[] }>;
};

export default async function RegisterPage({ searchParams }: RegisterPageProps) {
  const next = safeNextPath((await searchParams).next);

  if (await getCurrentUser()) {
    redirect(next ?? '/account');
  }

  return (
    <AuthLayout title="Create an account" intro="You need an account to place orders and keep track of them.">
      <AuthForm mode="signup" next={next} />
    </AuthLayout>
  );
}
