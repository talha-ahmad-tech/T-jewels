import Link from 'next/link';
import { buttonStyles, containerStyles } from './components/styles';

export default function NotFound() {
  return (
    <div className={`${containerStyles} flex flex-col items-center py-24 text-center`}>
      <p className="font-display text-7xl text-gold-ink">404</p>
      <h1 className="mt-4 text-4xl">We couldn’t find that page</h1>
      <p className="mt-3 max-w-md text-muted">The link may be wrong, or the piece may no longer be in the shop.</p>
      <Link href="/products" className={`${buttonStyles.primary} mt-8`}>
        Shop all jewellery
      </Link>
    </div>
  );
}
