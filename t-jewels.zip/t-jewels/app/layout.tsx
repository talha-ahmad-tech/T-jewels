import type { Metadata } from 'next';
import { Bodoni_Moda, Jost } from 'next/font/google';
import { unstable_rethrow } from 'next/navigation';
import { getCurrentUser } from '@/lib/session';
import Footer from './components/footer';
import Navbar from './components/navbar';
import './globals.css';

const bodoni = Bodoni_Moda({
  variable: '--font-bodoni',
  subsets: ['latin'],
  axes: ['opsz'],
  display: 'swap',
});

const jost = Jost({
  variable: '--font-jost',
  subsets: ['latin'],
  display: 'swap',
});

export const metadata: Metadata = {
  title: {
    default: 'T Jewels | Jewellery delivered across Pakistan',
    template: '%s | T Jewels',
  },
  description:
    'Rings, earrings, necklaces, bangles and bridal sets in sterling silver and gold vermeil. Cash on delivery anywhere in Pakistan.',
};

async function getNavbarUser() {
  try {
    const user = await getCurrentUser();
    return user ? { name: user.name } : null;
  } catch (error) {
    unstable_rethrow(error);
    return null;
  }
}

export default async function RootLayout({ children }: LayoutProps<'/'>) {
  const user = await getNavbarUser();

  return (
    <html lang="en" className={`${bodoni.variable} ${jost.variable} antialiased`}>
      <body className="flex min-h-dvh flex-col bg-white text-ink">
        <svg width="0" height="0" className="absolute" aria-hidden="true" focusable="false">
          <clipPath id="arch" clipPathUnits="objectBoundingBox">
            <path d="M0 1V.3C0 .15.2.07.5 0c.3.07.5.15.5.3V1Z" />
          </clipPath>
        </svg>
        <a
          href="#main"
          className="sr-only rounded-md bg-velvet px-4 py-2 text-white focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50"
        >
          Skip to content
        </a>
        <Navbar user={user} />
        <main id="main" className="flex-1">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  );
}
